// XCHandles, shared by the Generate and View tabs: "@name" → the xch1 address the handle points at.
//
// api.xchandles.com returns the handle's slot and its resolved NFT singleton; the address is that
// NFT's p2 puzzle hash, encoded as bech32m. Handles only exist on mainnet.
(() => {
  const API = 'https://api.xchandles.com';
  const RE = /^@([a-z0-9]{3,63})$/;

  // "@Name" → "name" when it is a well-formed handle, otherwise null.
  const parse = raw => {
    const m = String(raw || '').trim().toLowerCase().match(RE);
    return m ? m[1] : null;
  };

  // puzzle hash (hex) → bech32m address
  function encodeAddress(hrp, hex) {
    const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
    const data = [];
    let acc = 0, bits = 0;
    for (let i = 0; i < hex.length; i += 2) {
      acc = (acc << 8) | parseInt(hex.substr(i, 2), 16); bits += 8;
      while (bits >= 5) { bits -= 5; data.push((acc >> bits) & 31); }
    }
    if (bits) data.push((acc << (5 - bits)) & 31);
    const GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
    const polymod = values => {
      let chk = 1;
      for (const v of values) {
        const top = chk >>> 25;
        chk = ((chk & 0x1ffffff) << 5) ^ v;
        for (let i = 0; i < 5; i++) if ((top >>> i) & 1) chk ^= GEN[i];
      }
      return chk;
    };
    const expanded = [...[...hrp].map(c => c.charCodeAt(0) >> 5), 0, ...[...hrp].map(c => c.charCodeAt(0) & 31)];
    const mod = polymod([...expanded, ...data, 0, 0, 0, 0, 0, 0]) ^ 0x2bc830a3;
    const checksum = [0, 1, 2, 3, 4, 5].map(i => (mod >>> (5 * (5 - i))) & 31);
    return hrp + '1' + [...data, ...checksum].map(v => CHARSET[v]).join('');
  }

  // "name" (without @) → xch1 address; throws a readable error.
  async function resolve(name) {
    const get = async path => {
      const res = await fetch(API + path);
      if (res.status === 404) throw new Error(`@${name} is not a registered XCHandle.`);
      if (res.status === 410) throw new Error(`@${name} has expired.`);
      if (!res.ok) throw new Error(`XCHandles could not look up @${name} (HTTP ${res.status}).`);
      return res.json();
    };
    const d = await get(`/handle/${name}`);
    if (d.slot?.expiration && d.slot.expiration * 1000 < Date.now()) throw new Error(`@${name} has expired.`);
    let single = d.resolved_singleton;
    if (!single?.nft && d.slot?.resolved_launcher_id) single = await get(`/singletons/${d.slot.resolved_launcher_id}`);
    if (single?.melted) throw new Error(`@${name} points at an NFT that no longer exists.`);
    const ph = String(single?.nft?.p2_puzzle_hash || '').toLowerCase().replace(/^0x/, '');
    if (!/^[0-9a-f]{64}$/.test(ph)) throw new Error(`@${name} does not point at an address.`);
    return encodeAddress('xch', ph);
  }

  window.asciiHandles = { parse, resolve, encodeAddress,
    FORMAT_HINT: 'An XCHandle is @ followed by 3 to 63 lowercase letters and digits, e.g. @cassfairiesclub.' };
})();
