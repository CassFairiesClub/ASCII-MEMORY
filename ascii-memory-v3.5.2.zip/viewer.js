(() => {
  const $ = id => document.getElementById(id);
  const APIS = { mainnet: 'https://api.coinset.org', testnet11: 'https://testnet11.api.coinset.org' };
  const EXPLORER = { mainnet: 'https://www.spacescan.io/coin/', testnet11: 'https://testnet11.spacescan.io/coin/' };
  const PACK_PREFIX = 'asciiz:';
  // Inside a Sage App the webview can't open external links, so explorer links become plain text.
  const IN_SAGE = /^sage-app/.test(location.protocol) || /(^|\.)sage-app\.localhost$/.test(location.hostname) || !!window.__TAURI__ || !!window.__TAURI_INTERNALS__;
  if (IN_SAGE) document.documentElement.classList.add('in-sage');
  let run = 0;
  // feed.html and myfeed.html run this script in feed mode: no lookup form, a watched address instead.
  //   feed   → the shared ASCII-MEMORY address, 1 XCH minimum
  //   myfeed → the wallet's first unhardened address (from Sage), no minimum
  const PAGE = document.body.dataset.page;
  const FEED = PAGE === 'feed' || PAGE === 'myfeed';
  const MY_FEED = PAGE === 'myfeed';
  const { FEED_ADDRESS, FEED_MIN_MOJO } = window.asciiMemory;

  // ---------- helpers ----------
  const clean = h => (h || '').trim().toLowerCase().replace(/^0x/, '');
  const hexToBytes = h => { h = clean(h); const b = new Uint8Array(h.length / 2); for (let i = 0; i < b.length; i++) b[i] = parseInt(h.substr(i * 2, 2), 16); return b; };
  const bytesToHex = b => [...b].map(x => x.toString(16).padStart(2, '0')).join('');

  async function rpc(net, method, body) {
    const res = await fetch(`${APIS[net]}/${method}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    // Keep coin amounts exact: they can exceed 2^53.
    const text = (await res.text()).replace(/"amount":\s*(\d+)/g, '"amount":"$1"');
    return JSON.parse(text);
  }

  // CLVM int encoding: minimal big-endian two's complement.
  function amountBytes(amount) {
    let n = BigInt(amount);
    if (n === 0n) return new Uint8Array();
    let hex = n.toString(16);
    if (hex.length % 2) hex = '0' + hex;
    if (parseInt(hex[0], 16) >= 8) hex = '00' + hex;
    return hexToBytes(hex);
  }
  async function coinId(c) {
    const p = hexToBytes(c.parent_coin_info), ph = hexToBytes(c.puzzle_hash), a = amountBytes(c.amount);
    const buf = new Uint8Array(64 + a.length);
    buf.set(p, 0); buf.set(ph, 32); buf.set(a, 64);
    return bytesToHex(await sha256(buf));
  }

  async function sha256(bytes) {
    if (globalThis.crypto?.subtle) {
      try { return new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)); } catch { /* fall back */ }
    }
    return sha256js(bytes);
  }

  // Plain-JS SHA-256 for runtimes without WebCrypto (e.g. non-secure custom schemes).
  function sha256js(msg) {
    const K = new Uint32Array([
      0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
      0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
      0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
      0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
      0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
      0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
      0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
      0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
    const H = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
    const len = msg.length, total = Math.ceil((len + 9) / 64) * 64;
    const data = new Uint8Array(total);
    data.set(msg); data[len] = 0x80;
    const view = new DataView(data.buffer);
    view.setUint32(total - 8, Math.floor(len / 0x20000000)); view.setUint32(total - 4, len << 3);
    const w = new Uint32Array(64);
    const rotr = (x, n) => (x >>> n) | (x << (32 - n));
    for (let off = 0; off < total; off += 64) {
      for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4);
      for (let i = 16; i < 64; i++) {
        const s1 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        const s0 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (s0 + w[i - 7] + s1 + w[i - 16]) | 0;
      }
      let [a, b, c, d, e, f, g, h] = H;
      for (let i = 0; i < 64; i++) {
        const t1 = (h + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + ((e & f) ^ (~e & g)) + K[i] + w[i]) | 0;
        const t2 = ((rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + ((a & b) ^ (a & c) ^ (b & c))) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] += a; H[1] += b; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
    }
    const out = new Uint8Array(32), ov = new DataView(out.buffer);
    H.forEach((v, i) => ov.setUint32(i * 4, v));
    return out;
  }

  const blockCache = new Map();
  async function spendsAtHeight(net, height) {
    const key = net + ':' + height;
    if (!blockCache.has(key)) {
      blockCache.set(key, (async () => {
        const br = await rpc(net, 'get_block_record_by_height', { height });
        if (!br.success) throw new Error(`Block ${height} not found`);
        const bs = await rpc(net, 'get_block_spends_with_conditions', { header_hash: br.block_record.header_hash });
        if (!bs.success) throw new Error(`Could not load spends for block ${height}`);
        const spends = bs.block_spends_with_conditions;
        await Promise.all(spends.map(async s => { s.id = await coinId(s.coin_spend.coin); }));
        return { spends, timestamp: br.block_record.timestamp };
      })().catch(e => { blockCache.delete(key); throw e; }));
    }
    return blockCache.get(key);
  }

  // CREATE_COIN (opcode 51) conditions with a memo list → outputs
  function outputsWithMemos(spend) {
    return spend.conditions
      .filter(c => parseInt(c.opcode, 16) === 51 && Array.isArray(c.vars[2]))
      .map(c => ({ puzzle_hash: clean(c.vars[0]), amount: BigInt(c.vars[1] === '0x' ? 0 : c.vars[1]), memos: c.vars[2] }));
  }

  async function decodeMemo(hex) {
    const bytes = hexToBytes(hex);
    let text;
    try { text = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
    catch { return { kind: 'hex', text: '0x' + clean(hex), bytes: bytes.length }; }
    if (text.startsWith(PACK_PREFIX)) {
      try {
        const bin = atob(text.slice(PACK_PREFIX.length));
        const raw = Uint8Array.from(bin, ch => ch.charCodeAt(0));
        const stream = new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
        return { kind: 'packed', text: await new Response(stream).text(), bytes: bytes.length };
      } catch { /* fall through and show as-is */ }
    }
    return { kind: 'text', text, bytes: bytes.length };
  }

  // ---------- lookup ----------
  async function lookup(net, id, my) {
    status('Looking up coin…');
    const rec = await rpc(net, 'get_coin_record_by_name', { name: '0x' + id });
    if (my !== run) return;
    const found = [];

    if (rec.success && rec.coin_record) {
      const cr = rec.coin_record, coin = cr.coin;
      // (a) Memos attached to this coin when it was created (in its parent's spend).
      if (!cr.coinbase) {
        status(`Reading block ${cr.confirmed_block_index}…`);
        const blk = await spendsAtHeight(net, cr.confirmed_block_index);
        const parent = blk.spends.find(s => s.id === clean(coin.parent_coin_info));
        if (parent) {
          const outs = outputsWithMemos(parent).filter(o => o.puzzle_hash === clean(coin.puzzle_hash) && o.amount === BigInt(coin.amount));
          outs.forEach(o => found.push({ ...o, coin: id, height: cr.confirmed_block_index, timestamp: blk.timestamp }));
        }
      }
      // (b) Memos this coin attached to the coins it created when spent.
      if (cr.spent && cr.spent_block_index > 0) {
        status(`Reading block ${cr.spent_block_index}…`);
        const blk = await spendsAtHeight(net, cr.spent_block_index);
        const self = blk.spends.find(s => s.id === id);
        if (self) {
          for (const o of outputsWithMemos(self)) {
            const child = await coinId({ parent_coin_info: id, puzzle_hash: o.puzzle_hash, amount: o.amount.toString() });
            if (!found.some(f => f.coin === child)) found.push({ ...o, coin: child, height: cr.spent_block_index, timestamp: blk.timestamp });
          }
        }
      }
      // (c) Unspent, but its spend may be waiting in the mempool (e.g. a just-pushed inscription).
      if (!cr.spent) {
        const mp = await rpc(net, 'get_mempool_items_by_coin_name', { coin_name: '0x' + id });
        if (my !== run) return;
        if (mp.success && mp.mempool_items?.length) return waitForConfirmation(net, id, my);
      }
      if (my !== run) return;
      if (found.length) cachePut(net, id, found);
      return show(net, found, id);
    }

    // Not a coin: maybe a transaction ID still in the mempool.
    status('Not a coin on-chain yet — checking the mempool for a transaction…');
    const mp = await rpc(net, 'get_mempool_item_by_tx_id', { tx_id: '0x' + id });
    if (my !== run) return;
    if (mp.success && mp.mempool_item) {
      const removal = mp.mempool_item.removals?.[0] || mp.mempool_item.spend_bundle.coin_spends[0].coin;
      const rid = await coinId(removal);
      return waitForConfirmation(net, rid, my);
    }
    throw new Error('No coin or pending transaction found with that ID. A transaction ID only works while it waits in the mempool; after it confirms, use a coin ID from the transaction (for example from a block explorer or `chia wallet get_transaction`).');
  }

  async function waitForConfirmation(net, rid, my) {
    for (let tries = 0; my === run; tries++) {
      const r = await rpc(net, 'get_coin_record_by_name', { name: '0x' + rid });
      if (my !== run) return;
      if (r.success && r.coin_record?.spent) {
        setHash(net, rid);
        return lookup(net, rid, my);
      }
      status(`Transaction is pending in the mempool. Waiting for confirmation… (${tries * 20}s). This page will switch to the permanent coin ID link: ${rid}`);
      await new Promise(res => setTimeout(res, 20000));
    }
  }

  // ---------- rendering ----------
  async function show(net, found, id) {
    const out = $('out');
    out.innerHTML = '';
    const showHints = $('hints').checked;
    let shown = 0;
    for (const f of found) {
      const memos = await Promise.all(f.memos.map(decodeMemo));
      // A 32-byte memo that equals the puzzle hash is just a wallet hint.
      const isHint = (m, i) => i === 0 && clean(f.memos[0]).length === 64;
      // Convention from the generator: [art, title?, "memoart:v1;theme=…" style settings].
      const settingsMemo = memos.find(m => m.kind === 'text' && themes.parseSettings(m.text));
      const settings = settingsMemo ? themes.parseSettings(settingsMemo.text) : null;
      const art = memos.filter((m, i) => m !== settingsMemo && (showHints || !isHint(m, i)));
      if (!art.length) continue;
      const main = art.reduce((a, b) => (b.text.length > a.text.length ? b : a));
      const title = art.find(m => m !== main && m.kind === 'text' && m.text.length <= 120 && !m.text.includes('\n'));
      const extras = art.filter(m => m !== main && m !== title);
      for (const m of [main, ...extras]) { out.append(card(net, f, m, m === main ? title?.text : null, settings)); shown++; }
    }
    if (!shown) {
      status(found.length ? 'This coin has only wallet-hint memos (tick "Show hint-only memos" to see them).' : 'No memos found for this coin or the coins it created.', 'bad');
    } else status('');
    fitAll();
  }

  // "Auto" uses the style stored in the inscription (paper when there is none).
  const themes = window.memoArtThemes;
  function themeFor(settings) {
    const choice = $('style').value;
    return themes.byId(choice === 'auto' ? settings?.theme : choice);
  }
  function styleNote(settings) {
    const choice = $('style').value;
    if (choice !== 'auto') return `style: ${themes.byId(choice).name} (your choice)`;
    return settings?.theme ? `style: ${themes.byId(settings.theme).name} (from memo)` : 'style: default';
  }

  function card(net, f, m, title, settings) {
    const el = document.createElement('article');
    el.className = 'card';
    const head = document.createElement('div'); head.className = 'card-head';
    const h = document.createElement('h2'); h.textContent = title || 'Untitled';
    const copy = document.createElement('button'); copy.className = 'ghost'; copy.textContent = 'Copy';
    copy.onclick = async () => {
      if (await memoArt.copyText(m.text, 'ASCII art') === 'copied') flash(copy, 'Copied', 'Copy');
    };
    const dl = document.createElement('button'); dl.className = 'ghost'; dl.textContent = 'Download .txt';
    dl.onclick = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([m.text], { type: 'text/plain' })); a.download = `ascii-memory-${f.coin.slice(0, 8)}.txt`; a.click(); };
    head.append(h, copy);
    if (!IN_SAGE) head.append(dl); // text downloads stay hidden inside the Sage app webview
    if (m.kind !== 'hex') head.append(...pngButtons(f, m, title, settings));
    const stage = document.createElement('div'); stage.className = 'stage';
    const pre = document.createElement('pre'); pre.className = 'art' + (m.kind === 'hex' ? ' wrapText' : '');
    pre.textContent = m.text;
    stage.append(pre);
    const note = document.createElement('span'); note.className = 'style-note';
    // Re-applied when the Style picker changes.
    el.restyle = () => { themes.apply(stage, pre, themeFor(settings)); note.textContent = ' · ' + styleNote(settings); };
    el.restyle();
    const meta = document.createElement('div'); meta.className = 'meta';
    const date = f.timestamp ? new Date(f.timestamp * 1000).toISOString().replace('T', ' ').slice(0, 16) + ' UTC · ' : '';
    let link;
    if (IN_SAGE) {
      link = document.createElement('span');
    } else {
      link = document.createElement('a');
      link.href = EXPLORER[net] + '0x' + f.coin; link.target = '_blank'; link.rel = 'noopener';
    }
    link.textContent = '0x' + f.coin;
    meta.append(`${date}block ${f.height} · ${m.bytes} bytes${m.kind === 'packed' ? ' (packed)' : ''} · coin `, link, note);
    if (FEED) {
      meta.append(` · ${window.asciiAmounts.format(f.amount)}`);
      const open = document.createElement('a');
      open.className = 'card-open';
      open.href = `viewer.html#${net === 'mainnet' ? '' : net + ':'}0x${f.coin}`;
      open.textContent = 'Open in View →';
      meta.append(' · ', open);
    }
    el.append(head, stage, meta);
    return el;
  }

  // ---------- PNG export ----------
  // Draws the art on a canvas with the same line height as the page, in the card's terminal
  // style (colours, font, glow, scanlines). Optionally adds the title and coin ID as a caption.
  function renderPng(f, m, title, settings) {
    const scale = +$('pngScale').value || 2;
    const caption = $('pngCaption').checked;
    const lines = m.text.split('\n');
    const cols = Math.max(1, ...lines.map(l => l.length));
    const theme = themeFor(settings);
    const family = theme.font;
    const bg = theme.bg, fg = theme.fg;

    const probe = document.createElement('canvas').getContext('2d');
    probe.font = `100px ${family}`;
    const charW = probe.measureText('M').width / 100;          // per 1px of font size

    // Browsers cap canvases (~16k px per side, ~250M px area): shrink the font if needed.
    let size = 8 * scale;
    const dims = sz => {
      const pad = Math.round(sz * 2), lineH = sz * 1.15, capH = caption ? Math.round(sz * 3.2) : 0;
      return { pad, lineH, capH, w: Math.ceil(cols * charW * sz + pad * 2), h: Math.ceil(lines.length * lineH + pad * 2 + capH) };
    };
    let d = dims(size);
    while (size > 2 && (d.w > 16000 || d.h > 16000 || d.w * d.h > 120e6)) { size *= 0.9; d = dims(size); }

    const canvas = document.createElement('canvas');
    canvas.width = d.w; canvas.height = d.h;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = bg; ctx.fillRect(0, 0, d.w, d.h);
    ctx.fillStyle = fg; ctx.textBaseline = 'top';
    ctx.font = `${size}px ${family}`;
    if (theme.glow) { ctx.shadowColor = theme.glow; ctx.shadowBlur = Math.max(2, size * 0.6); }
    lines.forEach((line, i) => ctx.fillText(line, d.pad, d.pad + i * d.lineH));
    ctx.shadowBlur = 0; ctx.shadowColor = 'transparent';
    if (theme.scanlines) {
      const step = Math.max(3, Math.round(size / 3));
      ctx.fillStyle = 'rgba(0, 0, 0, 0.28)';
      for (let y = 0; y < d.h; y += step) ctx.fillRect(0, y, d.w, Math.max(1, Math.round(step / 3)));
      ctx.fillStyle = fg;
    }
    if (caption) {
      const y = d.h - d.pad - d.capH / 2;
      ctx.globalAlpha = 0.65;
      ctx.font = `${size * 1.1}px ${family}`;
      ctx.fillText(`${title || 'Untitled'} · block ${f.height}`, d.pad, y);
      ctx.font = `${size * 0.8}px ${family}`;
      ctx.fillText(`coin 0x${f.coin}`, d.pad, y + size * 1.4);
      ctx.globalAlpha = 1;
    }
    return new Promise((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('PNG encoding failed')), 'image/png'));
  }

  function flash(btn, text, label) {
    btn.textContent = text;
    setTimeout(() => btn.textContent = label, 1500);
  }

  function pngButtons(f, m, title, settings) {
    const filename = `ascii-memory-${f.coin.slice(0, 8)}.png`;
    const failed = (btn, label, e) => { flash(btn, 'PNG failed', label); console.error(e); };

    // Sage apps can neither download files nor write images to the clipboard:
    // open the PNG so it can be copied or saved from the right-click menu.
    if (memoArt.IN_SAGE) {
      const open = document.createElement('button');
      open.className = 'ghost'; open.textContent = 'PNG…';
      open.onclick = async () => {
        try { memoArt.showImage(await renderPng(f, m, title, settings), filename); } catch (e) { failed(open, 'PNG…', e); }
      };
      return [open];
    }

    const save = document.createElement('button');
    save.className = 'ghost'; save.textContent = 'Save PNG';
    save.onclick = async () => {
      try {
        const blob = await renderPng(f, m, title, settings);
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = filename;
        document.body.append(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      } catch (e) { failed(save, 'Save PNG', e); }
    };
    const copy = document.createElement('button');
    copy.className = 'ghost'; copy.textContent = 'Copy PNG';
    copy.onclick = async () => {
      const png = renderPng(f, m, title, settings);
      try {
        if (!window.ClipboardItem || !navigator.clipboard?.write) throw new Error('image clipboard unsupported');
        await navigator.clipboard.write([new ClipboardItem({ 'image/png': png })]);
        flash(copy, 'Copied', 'Copy PNG');
      } catch {
        try { memoArt.showImage(await png, filename); } catch (e) { failed(copy, 'Copy PNG', e); }
      }
    };
    return [save, copy];
  }

  // Art text size: a fixed size from the text size control for every card, or (Fit) per card,
  // the size at which its widest line fills the card. The control shows the first card's size.
  const charProbe = document.createElement('canvas').getContext('2d');
  const charWidth = pre => {                       // width of one character per 1px of font size
    charProbe.font = `100px ${getComputedStyle(pre).fontFamily}`;
    return charProbe.measureText('M').width / 100;
  };
  const artColumns = pre => Math.max(1, ...pre.textContent.split('\n').map(s => s.length));

  function fitAll() {
    let first = null;
    document.querySelectorAll('pre.art:not(.wrapText)').forEach(pre => {
      let px = textSize.size();
      if (textSize.isFit()) {
        const avail = pre.parentElement.clientWidth - 28;
        px = Math.max(2, Math.min(16, avail / (artColumns(pre) * charWidth(pre))));
      }
      pre.style.fontSize = px + 'px';
      if (first == null) first = px;
    });
    if (first != null) textSize.showFitSize(first);
    layoutCards();
  }

  // Feed cards shrink to the width their art actually needs, and flow into up to 3 columns
  // so small text sizes fill the page instead of leaving one narrow card per row.
  const MAX_CARD_COLUMNS = 3, CARD_GAP = 16, CARD_CHROME = 30, MIN_CARD_WIDTH = 280;
  function layoutCards() {
    const out = $('out');
    const cards = [...out.children].filter(el => el.classList.contains('card'));
    out.classList.toggle('cards-grid', cards.length > 1);
    if (cards.length < 2) { out.style.gridTemplateColumns = ''; cards.forEach(c => c.style.maxWidth = ''); return; }

    // Each card is only as wide as its own art; the column count follows the widest one,
    // so nothing has to scroll sideways.
    let widest = 0;
    for (const card of cards) {
      const pre = card.querySelector('pre.art:not(.wrapText)');
      if (!pre) { widest = out.clientWidth; card.style.maxWidth = ''; continue; }   // hex memo: full width
      const px = parseFloat(pre.style.fontSize) || parseFloat(getComputedStyle(pre).fontSize);
      const width = Math.max(MIN_CARD_WIDTH, Math.ceil(artColumns(pre) * charWidth(pre) * px + CARD_CHROME));
      card.style.maxWidth = width + 'px';
      widest = Math.max(widest, width);
    }
    const columns = Math.max(1, Math.min(MAX_CARD_COLUMNS,
      Math.floor((out.clientWidth + CARD_GAP) / (widest + CARD_GAP))));
    // max-content keeps the columns tight around the cards instead of spreading them out.
    out.style.gridTemplateColumns = `repeat(${columns}, minmax(0, max-content))`;
  }

  function status(t, cls = '') { $('status').textContent = t; $('status').className = cls; }

  function setHash(net, id) {
    const h = '#' + (net === 'mainnet' ? '' : net + ':') + '0x' + id;
    if (location.hash !== h) history.replaceState(null, '', h);
    $('id').value = '0x' + id; $('net').value = net;
  }

  // ---------- session cache ----------
  // Confirmed memos never change, so completed lookups are kept for the session: switching
  // between the Generate and View tabs (which reloads this page) redraws without calling
  // coinset.org again. Pending transactions and empty or failed lookups are never cached.
  const CACHE_KEY = 'memoart.viewerCache', CACHE_MAX = 6;

  function cacheRead() {
    try { const c = JSON.parse(sessionStorage.getItem(CACHE_KEY) || '[]'); return Array.isArray(c) ? c : []; }
    catch { return []; }
  }

  function cacheGet(net, id) {
    const hit = cacheRead().find(e => e.net === net && e.id === id);
    return hit ? hit.found.map(f => ({ ...f, amount: BigInt(f.amount) })) : null;
  }

  function cachePut(net, id, found) {
    let entries = cacheRead().filter(e => !(e.net === net && e.id === id));
    entries.unshift({ net, id, found: found.map(f => ({ ...f, amount: f.amount.toString() })) });
    entries = entries.slice(0, CACHE_MAX);
    // Large memos can exceed the storage quota: drop the oldest entries until it fits.
    while (entries.length) {
      try { sessionStorage.setItem(CACHE_KEY, JSON.stringify(entries)); return; }
      catch { entries.pop(); }
    }
  }

  function cachedNote(net, id) {
    const box = $('status');
    box.className = '';
    box.textContent = 'Shown from this session’s cache. ';
    const reload = document.createElement('button');
    reload.type = 'button'; reload.className = 'ghost'; reload.textContent = 'Reload from chain';
    reload.onclick = () => go(net, id, { fresh: true });
    box.append(reload);
  }

  async function go(net, raw, { fresh = false } = {}) {
    const id = clean(raw);
    const my = ++run;
    $('out').innerHTML = '';
    if (!/^[0-9a-f]{64}$/.test(id)) { status('Enter a 32-byte hex ID (64 hex characters, optionally prefixed with 0x).', 'bad'); return; }
    setHash(net, id);
    try { sessionStorage.setItem('memoart.viewerLast', JSON.stringify({ net, id })); } catch { /* storage unavailable */ }
    const cached = fresh ? null : cacheGet(net, id);
    if (cached) {
      await show(net, cached, id);
      if (my === run && $('out').children.length) cachedNote(net, id);
      return;
    }
    try { await lookup(net, id, my); }
    catch (e) { if (my === run) status(e.message || String(e), 'bad'); }
  }

  function fromLocation() {
    const q = new URLSearchParams(location.search);
    let raw = q.get('id') || q.get('coin') || q.get('tx') || location.hash.slice(1);
    let net = q.get('net') || 'mainnet';
    const m = raw.match(/^(testnet11|mainnet):(.*)$/);
    if (m) { net = m[1]; raw = m[2]; }
    if (!raw) {
      // Coming back from the Generate tab: show the last inscription of this session.
      try { const last = JSON.parse(sessionStorage.getItem('memoart.viewerLast') || 'null'); if (last) { raw = last.id; net = last.net; } } catch { /* ignore */ }
    }
    if (raw) { $('net').value = APIS[net] ? net : 'mainnet'; go($('net').value, raw); }
  }

  // ---------- THE FEED ----------
  // Watches FEED_ADDRESS and indexes every eligible inscription it ever received: a coin of at least
  // FEED_MIN_MOJO (1 XCH) whose memos look like our ASCII art. Smaller coins are skipped without
  // reading their block. The index (coin, amount, height…) never changes once confirmed, so it is
  // kept on this device and later checks only ask for coins from the last seen height on. Memo text
  // is fetched only for the cards on screen and kept for the session.
  const FEED_SCAN_MAX = 200, FEED_POLL_MS = 60000;
  // Storage keys are per feed: "My feed" also keys on the address, so several wallets keep separate indexes.
  const keyFor = (what, suffix = '') => `asciimemory.${MY_FEED ? 'myFeed' : 'feed'}${what}.v1${suffix}`;
  let FEED_INDEX_KEY = keyFor('Index');                  // localStorage
  let FEED_MEMOS_KEY = keyFor('Memos');                  // sessionStorage
  const FEED_PREFS_KEY = keyFor('Prefs');                // localStorage
  const feed = {
    address: FEED_ADDRESS, min: BigInt(FEED_MIN_MOJO),
    net: 'mainnet', ph: null,
    eligible: [],            // { coin, parent_coin_info, puzzle_hash, amount: BigInt, height, timestamp }
    checked: new Set(),      // every coin id already classified (eligible or not)
    memos: new Map(),        // coin id → memo hex list
    lastHeight: 0, lastCheck: 0, busy: false, timer: 0, newSince: 0,
  };

  // bech32m address → puzzle hash (hex); throws on a bad checksum.
  function decodeAddress(address) {
    const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
    const pos = address.lastIndexOf('1');
    const hrp = address.slice(0, pos), data = [...address.slice(pos + 1)].map(ch => CHARSET.indexOf(ch));
    if (pos < 1 || data.some(v => v < 0)) throw new Error('invalid address');
    const GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
    let chk = 1;
    for (const v of [...[...hrp].map(c => c.charCodeAt(0) >> 5), 0, ...[...hrp].map(c => c.charCodeAt(0) & 31), ...data]) {
      const top = chk >>> 25;
      chk = ((chk & 0x1ffffff) << 5) ^ v;
      for (let i = 0; i < 5; i++) if ((top >>> i) & 1) chk ^= GEN[i];
    }
    if ((chk >>> 0) !== 0x2bc830a3) throw new Error('address checksum mismatch');
    let acc = 0, bits = 0; const out = [];
    for (const v of data.slice(0, -6)) {
      acc = (acc << 5) | v; bits += 5;
      while (bits >= 8) { bits -= 8; out.push((acc >> bits) & 0xff); }
    }
    return { hrp, puzzleHash: bytesToHex(out) };
  }

  // Our format: a "memoart:v1;" style memo or a packed "asciiz:" memo, or multi-line printable ASCII art.
  async function isMemoArt(f) {
    const memos = await Promise.all(f.memos.map(decodeMemo));
    return memos.some(m =>
      m.kind === 'packed' ||
      (m.kind === 'text' && (themes.parseSettings(m.text) ||
        (/^[\x20-\x7e\n]+$/.test(m.text) && m.text.split('\n').length >= 3 && Math.max(...m.text.split('\n').map(l => l.length)) >= 8))));
  }

  // ----- persistence -----
  const tryJson = (storage, key) => { try { return JSON.parse(storage.getItem(key) || 'null'); } catch { return null; } };

  function feedSaveIndex() {
    const data = {
      v: 1, address: feed.address, min: String(feed.min),
      eligible: feed.eligible.map(e => ({ ...e, amount: e.amount.toString() })),
      checked: [...feed.checked], lastHeight: feed.lastHeight, lastCheck: feed.lastCheck,
    };
    try { localStorage.setItem(FEED_INDEX_KEY, JSON.stringify(data)); } catch { /* storage unavailable */ }
  }

  function feedLoadIndex() {
    const d = tryJson(localStorage, FEED_INDEX_KEY);
    // A different address or minimum invalidates the index.
    if (!d || d.v !== 1 || d.address !== feed.address || d.min !== String(feed.min)) return false;
    feed.eligible = (d.eligible || []).map(e => ({ ...e, amount: BigInt(e.amount) }));
    feed.checked = new Set(d.checked || []);
    feed.lastHeight = d.lastHeight || 0;
    feed.lastCheck = d.lastCheck || 0;
    const memos = tryJson(sessionStorage, FEED_MEMOS_KEY);
    if (memos) for (const [coin, list] of Object.entries(memos)) feed.memos.set(coin, list);
    return feed.lastHeight > 0;
  }

  function feedSaveMemos(keep) {
    // Keep the memos of the cards on screen first; drop the rest if storage runs out.
    const entries = [...feed.memos.entries()].sort(([a], [b]) => (keep.has(b) ? 1 : 0) - (keep.has(a) ? 1 : 0));
    while (entries.length) {
      try { sessionStorage.setItem(FEED_MEMOS_KEY, JSON.stringify(Object.fromEntries(entries))); return; }
      catch { entries.pop(); }
    }
    try { sessionStorage.removeItem(FEED_MEMOS_KEY); } catch { /* ignore */ }
  }

  function feedPrefs() {
    const p = tryJson(localStorage, FEED_PREFS_KEY) || {};
    return { count: ['5', '10', '20', '50', 'all'].includes(p.count) ? p.count : '10', sort: p.sort === 'amount' ? 'amount' : 'newest' };
  }

  function feedSavePrefs() {
    try { localStorage.setItem(FEED_PREFS_KEY, JSON.stringify({ count: $('feedCount').value, sort: $('feedSort').value })); } catch { /* ignore */ }
  }

  // ----- display -----

  function feedSelection() {
    const byNewest = (a, b) => b.height - a.height || (a.coin < b.coin ? -1 : 1);
    const list = [...feed.eligible].sort($('feedSort').value === 'amount'
      ? (a, b) => (b.amount > a.amount ? 1 : b.amount < a.amount ? -1 : byNewest(a, b))
      : byNewest);
    const count = $('feedCount').value;
    return count === 'all' ? list : list.slice(0, +count);
  }

  function feedTotals() {
    const total = feed.eligible.length;
    const sum = feed.eligible.reduce((s, e) => s + e.amount, 0n);
    $('feedTotal').textContent = total.toLocaleString();
    const word = MY_FEED ? 'inscription' : 'eligible inscription';
    $('feedTotalLabel').textContent = total === 1 ? word : word + 's';
    $('feedTotalXch').textContent = total ? `${window.asciiAmounts.format(sum)} received in total` : '';
    $('feedNew').hidden = !feed.newSince;
    $('feedNew').textContent = `+${feed.newSince} new`;
    const sort = $('feedSort').value === 'amount' ? 'highest XCH first' : 'newest first';
    const shown = Math.min(total, $('feedCount').value === 'all' ? total : +$('feedCount').value);
    $('feedShowing').textContent = total ? `· Showing ${shown} of ${total}, ${sort}.` : '';
  }

  async function feedEnsureMemos(items) {
    for (const e of items) {
      if (feed.memos.has(e.coin)) continue;
      feedStatus(`Loading art from block ${e.height}…`, 'busy');
      const blk = await spendsAtHeight(feed.net, e.height);
      const parent = blk.spends.find(s => s.id === clean(e.parent_coin_info));
      const out = parent && outputsWithMemos(parent).find(o => o.puzzle_hash === clean(e.puzzle_hash) && o.amount === e.amount);
      if (out) feed.memos.set(e.coin, out.memos);
    }
  }

  let feedRenderRun = 0;
  async function feedRender() {
    const mine = ++feedRenderRun;
    feedTotals();
    const items = feedSelection();
    if (!items.length) {
      ++run; $('out').innerHTML = '';
      status(MY_FEED
        ? 'No ASCII art has been sent to your first address yet. Inscribe to yourself from the Generate tab with Use my Sage address.'
        : 'No ASCII art of at least 1 XCH has been sent to this address yet. Be the first: use Send to THE FEED on the Generate tab.');
      return;
    }
    try { await feedEnsureMemos(items); }
    catch (e) { status('Could not load some inscriptions: ' + (e.message || e), 'bad'); }
    if (mine !== feedRenderRun) return;
    feedSaveMemos(new Set(items.map(e => e.coin)));
    const found = items.filter(e => feed.memos.has(e.coin)).map(e => ({ ...e, memos: feed.memos.get(e.coin) }));
    ++run;
    await show(feed.net, found, null);
    if (!feed.busy) feedIdle();
  }

  function feedStatus(text, state) {
    $('feedStatus').textContent = text;
    $('feedLive').className = 'feed-live' + (state ? ' ' + state : '');
  }

  function feedIdle() {
    const when = feed.lastCheck ? new Date(feed.lastCheck).toLocaleTimeString() : 'never';
    feedStatus(`Watching · last checked ${when}`, document.hidden ? '' : 'on');
  }

  // ----- checking the chain -----
  async function feedCheck({ initial = false } = {}) {
    if (feed.busy) return;
    feed.busy = true;
    $('feedRefresh').disabled = true;
    feedStatus(feed.lastHeight ? 'Checking for new inscriptions…' : `Indexing ${MY_FEED ? 'your address' : 'the feed address'}…`, 'busy');
    try {
      const body = { puzzle_hash: '0x' + feed.ph, include_spent_coins: true };
      if (feed.lastHeight) body.start_height = feed.lastHeight;
      const res = await rpc(feed.net, 'get_coin_records_by_puzzle_hash', body);
      if (!res.success) throw new Error(res.error || 'coinset.org refused the request');
      const all = res.coin_records || [];
      const newestHeight = Math.max(0, ...all.map(r => r.confirmed_block_index));
      const records = all
        .filter(r => !r.coinbase && BigInt(r.coin.amount) >= feed.min)
        .sort((a, b) => b.confirmed_block_index - a.confirmed_block_index);

      let scanned = 0, added = 0, capped = false;
      for (const r of records) {
        const id = await coinId(r.coin);
        if (feed.checked.has(id)) continue;
        if (scanned++ >= FEED_SCAN_MAX) { capped = true; break; }
        feedStatus(`Reading block ${r.confirmed_block_index}…`, 'busy');
        const blk = await spendsAtHeight(feed.net, r.confirmed_block_index);
        const parent = blk.spends.find(s => s.id === clean(r.coin.parent_coin_info));
        const out = parent && outputsWithMemos(parent).find(o => o.puzzle_hash === clean(r.coin.puzzle_hash) && o.amount === BigInt(r.coin.amount));
        if (out) {
          const f = { ...out, coin: id, height: r.confirmed_block_index, timestamp: blk.timestamp };
          if (await isMemoArt(f)) {
            feed.eligible.push({ coin: id, parent_coin_info: clean(r.coin.parent_coin_info), puzzle_hash: out.puzzle_hash,
              amount: out.amount, height: r.confirmed_block_index, timestamp: blk.timestamp });
            feed.memos.set(id, out.memos);
            added++;
          }
        }
        feed.checked.add(id);
      }
      // If the scan stopped early, keep the height so the next check continues where this one left off.
      if (!capped) feed.lastHeight = Math.max(feed.lastHeight, newestHeight);
      feed.lastCheck = Date.now();
      if (added && !initial) feed.newSince += added;
      feedSaveIndex();
      if (added || !$('out').children.length) await feedRender();
      else feedTotals();
      if (capped) setTimeout(() => feedCheck(), 1000);
    } catch (e) {
      status('Feed check failed: ' + (e.message || e), 'bad');
    } finally {
      feed.busy = false;
      $('feedRefresh').disabled = false;
      feedIdle();
    }
  }

  function feedSchedule() {
    clearTimeout(feed.timer);
    feed.timer = setTimeout(async () => {
      if (!document.hidden) await feedCheck();
      feedSchedule();
    }, FEED_POLL_MS);
  }

  // My feed: ask Sage for the wallet's first unhardened address, through the app bridge
  // (window.__SAGE__) or, in a browser, through sage_bridge.py. ?address=xch1… overrides both.
  async function resolveMyAddress() {
    const override = new URLSearchParams(location.search).get('address');
    if (override) return override.trim();
    if (IN_SAGE) {
      for (let i = 0; i < 40 && !window.__SAGE__; i++) await new Promise(r => setTimeout(r, 50));
      if (!window.__SAGE__) throw new Error('the Sage app bridge is not available');
      const res = await window.__SAGE__.wallet.getDerivations({ hardened: false, offset: 0, limit: 1 });
      return res.derivations?.[0]?.address;
    }
    if (/^https?:$/.test(location.protocol)) {
      const r = await fetch('/sage/get_derivations', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Memo-Art': '1' },
        body: JSON.stringify({ hardened: false, offset: 0, limit: 1 }),
      });
      if (!r.ok) throw new Error((await r.text()) || `${r.status} ${r.statusText}`);
      const d = await r.json();
      return d.derivations?.[0]?.address;
    }
    return null;
  }

  async function startFeed() {
    if (MY_FEED) {
      feedStatus('Asking Sage for your first address…', 'busy');
      let address = null;
      try { address = await resolveMyAddress(); }
      catch (e) { feedStatus('Sage refused: ' + (e.message || e)); return; }
      if (!address) {
        feedStatus('Open this tab inside the ASCII-MEMORY Sage app, or run sage_bridge.py, to see the inscriptions sent to your wallet.');
        return;
      }
      feed.address = address;
      feed.min = 0n;
      feed.net = address.startsWith('txch1') ? 'testnet11' : 'mainnet';
      FEED_INDEX_KEY = keyFor('Index', ':' + address);
      FEED_MEMOS_KEY = keyFor('Memos', ':' + address);
    }
    $('feedAddress').textContent = feed.address;
    try { feed.ph = decodeAddress(feed.address).puzzleHash; }
    catch (e) { feedStatus('That address is invalid: ' + e.message); return; }

    const prefs = feedPrefs();
    $('feedCount').value = prefs.count;
    $('feedSort').value = prefs.sort;
    const onPrefs = () => { feedSavePrefs(); feed.newSince = 0; feedRender(); };
    $('feedCount').onchange = onPrefs;
    $('feedSort').onchange = onPrefs;
    $('feedRefresh').onclick = () => feedCheck();
    $('feedNew').onclick = () => { feed.newSince = 0; feedTotals(); };

    document.addEventListener('visibilitychange', () => {
      if (document.hidden) { feedIdle(); return; }
      // Back from another tab or window: check right away if the last check is stale.
      if (Date.now() - feed.lastCheck > FEED_POLL_MS) feedCheck(); else feedIdle();
    });
    if (feedLoadIndex()) {
      await feedRender();          // from the saved index (memos from the session, or fetched)
      if (Date.now() - feed.lastCheck > FEED_POLL_MS) await feedCheck();
    } else {
      await feedCheck({ initial: true });
    }
    feedSchedule();
  }

  themes.fillSelect($('style'), { auto: 'Auto (from memo)' });
  $('style').value = 'auto';
  $('style').onchange = () => { document.querySelectorAll('.card').forEach(c => c.restyle?.()); fitAll(); };
  const textSize = memoArtTextSize.create({ root: $('textSize'), storageKey: FEED ? 'memoart.textSize.feed' : 'memoart.textSize.viewer', onChange: () => fitAll() });
  window.addEventListener('resize', fitAll);
  if (FEED) {
    // Amount units changed in the footer: redraw the totals and the cards.
    window.asciiAmounts.onChange(() => { if (feed.ph) feedRender(); });
    startFeed();
  } else {
    $('form').onsubmit = e => { e.preventDefault(); go($('net').value, $('id').value); };
    $('hints').onchange = () => $('id').value && go($('net').value, $('id').value);
    window.addEventListener('hashchange', fromLocation);
    fromLocation();
  }
})();
