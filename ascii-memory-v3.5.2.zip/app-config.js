// App-wide settings shared by generator.html, viewer.html and feed.html.
window.asciiMemory = Object.freeze({
  NAME: 'ASCII-MEMORY',
  CREDIT: 'ASCII-MEMORY by Cass - 2026',
  // THE FEED watches this address and only shows inscriptions that sent it at least FEED_MIN_MOJO.
  FEED_ADDRESS: 'xch1khfj4wj6wt783wxzysgt5etws3hy2s03025k0m3dy707ul8x9hnq2w0cym',
  FEED_MIN_MOJO: 1_000_000_000_000, // 1 XCH
});
