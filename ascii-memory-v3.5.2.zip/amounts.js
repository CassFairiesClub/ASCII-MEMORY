// One place to format Chia amounts, shared by every page.
//
// Amounts are always given in mojo (Number, BigInt or numeric string) and shown with the
// locale's thousands and decimal separators. The footer setting picks the units:
//   both (default) → "1.5 XCH (1,500,000,000,000 mojo)"
//   xch            → "1.5 XCH"
//   mojo           → "1,500,000,000,000 mojo"
// Conversion uses BigInt, so amounts beyond 2^53 mojo stay exact.
(() => {
  const MOJO_PER_XCH = 1_000_000_000_000n;
  const KEY = 'asciimemory.amountMode.v1';
  const MODES = { both: 'XCH + mojo', xch: 'XCH only', mojo: 'Mojo only' };
  const listeners = new Set();

  const groups = new Intl.NumberFormat(undefined, { useGrouping: true });
  const DECIMAL = new Intl.NumberFormat(undefined).formatToParts(1.1).find(p => p.type === 'decimal')?.value || '.';

  const toBigInt = value => {
    if (typeof value === 'bigint') return value;
    if (typeof value === 'number') return BigInt(Math.round(value));
    return BigInt(String(value ?? '0').trim() || '0');
  };

  let mode = 'both';
  try { if (MODES[localStorage.getItem(KEY)]) mode = localStorage.getItem(KEY); } catch { /* storage unavailable */ }

  function xchText(mojo) {
    const negative = mojo < 0n;
    const abs = negative ? -mojo : mojo;
    const whole = abs / MOJO_PER_XCH;
    const fraction = (abs % MOJO_PER_XCH).toString().padStart(12, '0').replace(/0+$/, '');
    return (negative ? '-' : '') + groups.format(whole) + (fraction ? DECIMAL + fraction : '');
  }

  const mojoText = mojo => groups.format(mojo);

  // format(1500000000000) → "1.5 XCH (1,500,000,000,000 mojo)"
  function format(value, { mode: override } = {}) {
    const mojo = toBigInt(value);
    const which = MODES[override] ? override : mode;
    if (which === 'xch') return `${xchText(mojo)} XCH`;
    if (which === 'mojo') return `${mojoText(mojo)} mojo`;
    return `${xchText(mojo)} XCH (${mojoText(mojo)} mojo)`;
  }

  function setMode(next) {
    if (!MODES[next] || next === mode) return;
    mode = next;
    try { localStorage.setItem(KEY, mode); } catch { /* storage unavailable */ }
    for (const fn of listeners) { try { fn(mode); } catch (e) { console.error(e); } }
  }

  // Fills the footer's <select id="amountMode"> and re-runs listeners when it changes.
  function mountSetting() {
    const select = document.getElementById('amountMode');
    if (!select) return;
    select.textContent = '';
    for (const [value, label] of Object.entries(MODES)) select.append(new Option(label, value));
    select.value = mode;
    select.addEventListener('change', () => setMode(select.value));
  }

  window.asciiAmounts = {
    format, xch: v => `${xchText(toBigInt(v))} XCH`, mojo: v => `${mojoText(toBigInt(v))} mojo`,
    getMode: () => mode, setMode, onChange: fn => listeners.add(fn), mountSetting,
  };
  document.addEventListener('DOMContentLoaded', mountSetting);
})();
