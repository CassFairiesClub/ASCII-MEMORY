(() => {
  const $ = id => document.getElementById(id);
  const COST_PER_BYTE = 12000;
  const BASE_TX_COST = 15_000_000;      // rough cost of a plain 1-in / 2-out standard XCH spend
  const MAX_TX_COST = 5_500_000_000;    // mempool per-transaction cap (MAX_BLOCK_COST_CLVM / 2)
  const MIN_FPC = 5;                    // mempool's minimum non-zero fee per cost
  const MAX_MEMO_BYTES = Math.floor((MAX_TX_COST - BASE_TX_COST) / COST_PER_BYTE);
  const PACK_PREFIX = 'asciiz:';
  const enc = new TextEncoder();

  let img = null, imageName = '', current = null, job = 0;

  // ---------- image input ----------
  const drop = $('drop'), file = $('file');
  drop.onclick = () => file.click();
  drop.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') file.click(); };
  file.onchange = () => file.files[0] && load(file.files[0]);
  ['dragenter', 'dragover'].forEach(t => drop.addEventListener(t, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(t => drop.addEventListener(t, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => e.dataTransfer.files[0] && load(e.dataTransfer.files[0]));
  window.addEventListener('paste', e => {
    const f = [...(e.clipboardData?.files || [])].find(f => f.type.startsWith('image/'));
    if (f) load(f);
  });

  function load(f) {
    if (!/^image\/(png|jpeg)$/.test(f.type)) { setMsg('Please use a PNG or JPEG file.', 'bad'); return; }
    showImage(URL.createObjectURL(f), f.name, false);
  }

  // restoring: the image comes from the saved draft, so keep any restored hand edits.
  function showImage(url, name, restoring) {
    const im = document.createElement('img');
    im.onload = () => {
      img = im;
      imageName = name;
      if (edit.active && !restoring) discardEdits(false);
      drop.innerHTML = '';
      const thumb = document.createElement('img'); thumb.src = url; thumb.alt = '';
      const cap = document.createElement('div');
      cap.textContent = `${name} · ${im.naturalWidth}×${im.naturalHeight}`;
      drop.append(thumb, cap);
      if (!restoring) saveDraftSoon({ image: true });
      schedule();
    };
    im.onerror = () => setMsg('Could not decode that image.', 'bad');
    im.src = url;
  }

  // ---------- controls ----------
  const sliders = { brightness: v => (v > 0 ? '+' : '') + (+v).toFixed(2), contrast: v => (+v).toFixed(2),
    gamma: v => (+v).toFixed(2), sharpen: v => (+v).toFixed(2), aspect: v => (+v).toFixed(2) };
  for (const [id, fmt] of Object.entries(sliders)) {
    $(id).addEventListener('input', () => { $(id + 'V').textContent = fmt($(id).value); schedule(); });
  }
  ['budget', 'cols', 'title', 'ramp'].forEach(id => $(id).addEventListener('input', schedule));
  ['dither', 'invert', 'trim', 'pack'].forEach(id => $(id).addEventListener('change', schedule));
  $('budgetPreset').onchange = () => { if ($('budgetPreset').value) { $('budget').value = $('budgetPreset').value; $('budgetPreset').value = ''; schedule(); } };
  $('widthMode').onchange = () => { $('colsLabel').textContent = $('widthMode').value === 'auto' ? 'max columns' : 'columns'; schedule(); };
  $('rampPreset').onchange = () => {
    const v = $('rampPreset').value;
    $('ramp').hidden = v !== 'custom';
    if (v !== 'custom') $('ramp').value = v;
    schedule();
  };
  // Terminal style: restyle the preview, pick the matching brightness mapping, re-render
  // (the style memo is part of the byte budget).
  const themes = window.memoArtThemes;
  themes.fillSelect($('theme'));
  $('theme').value = themes.DEFAULT;
  function applyTheme() {
    const theme = themes.byId($('theme').value);
    themes.apply($('stage'), $('art'), theme);
    themes.apply($('stage'), $('artEdit'), theme);
    return theme;
  }
  $('theme').onchange = () => {
    $('invert').checked = applyTheme().dark;
    schedule();
  };
  applyTheme();
  const textSize = memoArtTextSize.create({ root: $('textSize'), storageKey: 'memoart.textSize.generator', onChange: () => fitFont() });
  window.addEventListener('resize', fitFont);
  ['addr', 'walletId', 'amount', 'fee'].forEach(id => $(id).addEventListener('input', updateButtons));

  let timer;
  function schedule() { clearTimeout(timer); timer = setTimeout(render, 60); }

  function opts() {
    let ramp = [...$('ramp').value].filter(c => c.charCodeAt(0) >= 32 && c.charCodeAt(0) < 127).join('');
    if (ramp.length < 2) ramp = ' #';
    return {
      ramp, brightness: +$('brightness').value, contrast: +$('contrast').value, gamma: +$('gamma').value,
      sharpen: +$('sharpen').value, aspect: +$('aspect').value, dither: $('dither').checked,
      invert: $('invert').checked, trim: $('trim').checked,
    };
  }

  // ---------- conversion ----------
  const cvs = document.createElement('canvas');
  const ctx = cvs.getContext('2d', { willReadFrequently: true });

  function rowsFor(cols, aspect) {
    return Math.max(1, Math.round(cols * (img.naturalHeight / img.naturalWidth) * aspect));
  }

  function toAscii(cols, o) {
    const rows = rowsFor(cols, o.aspect);
    cvs.width = cols; cvs.height = rows;
    // Composite over the "paper" colour so transparent pixels become blank.
    ctx.fillStyle = o.invert ? '#000' : '#fff';
    ctx.fillRect(0, 0, cols, rows);
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, cols, rows);
    const px = ctx.getImageData(0, 0, cols, rows).data;
    const n = cols * rows;
    let lum = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      const r = px[i * 4], g = px[i * 4 + 1], b = px[i * 4 + 2];
      lum[i] = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    }
    if (o.sharpen > 0) {
      const out = new Float32Array(n);
      for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
        const i = y * cols + x;
        const l = lum[x > 0 ? i - 1 : i], r = lum[x < cols - 1 ? i + 1 : i];
        const u = lum[y > 0 ? i - cols : i], d = lum[y < rows - 1 ? i + cols : i];
        out[i] = lum[i] + o.sharpen * (4 * lum[i] - l - r - u - d) / 4;
      }
      lum = out;
    }
    const levels = o.ramp.length - 1;
    const q = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      let v = (lum[i] - 0.5) * o.contrast + 0.5 + o.brightness;
      v = Math.min(1, Math.max(0, v));
      v = Math.pow(v, o.gamma);
      if (o.invert) v = 1 - v;
      q[i] = (1 - v) * levels;           // 0 = lightest char (space), levels = densest
    }
    const idx = new Uint8Array(n);
    for (let y = 0; y < rows; y++) for (let x = 0; x < cols; x++) {
      const i = y * cols + x;
      const k = Math.min(levels, Math.max(0, Math.round(q[i])));
      idx[i] = k;
      if (o.dither) {
        const e = q[i] - k;
        if (x + 1 < cols) q[i + 1] += e * 7 / 16;
        if (y + 1 < rows) {
          if (x > 0) q[i + cols - 1] += e * 3 / 16;
          q[i + cols] += e * 5 / 16;
          if (x + 1 < cols) q[i + cols + 1] += e * 1 / 16;
        }
      }
    }
    let lines = [];
    for (let y = 0; y < rows; y++) {
      let s = '';
      for (let x = 0; x < cols; x++) s += o.ramp[idx[y * cols + x]];
      lines.push(s);
    }
    if (o.trim) {
      lines = lines.map(s => s.replace(/ +$/, ''));
      while (lines.length && !lines[0]) lines.shift();
      while (lines.length && !lines[lines.length - 1]) lines.pop();
      const indent = Math.min(...lines.filter(Boolean).map(s => s.match(/^ */)[0].length));
      if (isFinite(indent) && indent > 0) lines = lines.map(s => s.slice(indent));
    }
    return { text: lines.join('\n'), cols, rows };
  }

  async function pack(text) {
    const stream = new Blob([text]).stream().pipeThrough(new CompressionStream('deflate-raw'));
    const bytes = new Uint8Array(await new Response(stream).arrayBuffer());
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    return PACK_PREFIX + btoa(bin);
  }

  async function build(cols, o, packIt) {
    const r = toAscii(cols, o);
    r.memo = packIt ? await pack(r.text) : r.text;
    return r;
  }

  // Memo order: [art, title?, style settings]
  const memoList = (memo, title, settings) => [memo, ...(title ? [title] : []), settings];
  const memoBytes = (memo, title, settings) => memoList(memo, title, settings).reduce((n, m) => n + enc.encode(m).length, 0);
  const styleSettings = () => themes.encodeSettings({ theme: $('theme').value });

  async function render() {
    if (edit.active) return refreshEdited();
    if (!img) return;
    const my = ++job;
    const o = opts();
    const packIt = $('pack').checked;
    const title = $('title').value.trim();
    const settings = styleSettings();
    const budget = Math.min(MAX_MEMO_BYTES, Math.max(1, +$('budget').value || 0));
    let result;

    if ($('widthMode').value === 'auto') {
      const fits = async c => { const r = await build(c, o, packIt); return memoBytes(r.memo, title, settings) <= budget ? r : null; };
      let lo = 4, hi = Math.max(4, Math.min(2000, +$('cols').value || 240)), best = await fits(lo);
      if (!best) { if (my === job) showResult(await build(lo, o, packIt), o, budget, title, settings, 'Budget too small for even 4 columns.'); return; }
      while (lo < hi) {
        const mid = Math.ceil((lo + hi) / 2);
        const r = await fits(mid);
        if (my !== job) return;
        if (r) { lo = mid; best = r; } else hi = mid - 1;
      }
      result = best;
    } else {
      result = await build(Math.max(4, Math.min(2000, +$('cols').value || 80)), o, packIt);
    }
    if (my === job) showResult(result, o, budget, title, settings);
  }

  function showResult(r, o, budget, title, settings, err) {
    current = { ...r, title, settings };
    if (sage.built) discardReview();
    const bytes = memoBytes(r.memo, title, settings);
    const cost = BASE_TX_COST + bytes * COST_PER_BYTE;
    const lines = r.text.split('\n');
    $('art').textContent = r.text;
    $('sBytes').textContent = bytes.toLocaleString() + ' / ' + budget.toLocaleString();
    $('sDims').textContent = `${Math.max(...lines.map(s => s.length))} × ${lines.length}`;
    $('sCost').textContent = (cost / 1e6).toFixed(1) + ' M';
    $('sFee').textContent = amounts.format(cost * MIN_FPC);
    const pct = Math.min(100, (bytes / budget) * 100);
    $('meter').firstElementChild.style.width = pct + '%';
    $('meter').classList.toggle('over', bytes > budget);
    if (err) setMsg(err, 'bad');
    else if (bytes > budget) setMsg(`Over budget by ${(bytes - budget).toLocaleString()} bytes. Reduce the columns or switch to "Largest that fits".`, 'bad');
    else if (cost > MAX_TX_COST) setMsg('Exceeds the mempool per-transaction cost cap.', 'bad');
    else if (bytes > 100000) setMsg('Large memo: it will take up a big share of a block and may need a fee to be included.', 'warn');
    else setMsg(($('pack').checked ? `Packed: ${r.text.length.toLocaleString()} characters of art compressed into the memo. ` : 'Plain ASCII: readable on any block explorer. ') + `Mempool max ≈ ${MAX_MEMO_BYTES.toLocaleString()} bytes.`);
    updateButtons();
    fitFont();
    saveDraftSoon();
  }

  // Every amount goes through the shared formatter, so the footer's Amounts setting applies.
  const amounts = window.asciiAmounts;
  const fmtXch = mojo => amounts.format(mojo);

  function setMsg(t, cls = '') { $('msg').textContent = t; $('msg').className = 'msg ' + cls; }

  // Preview/editor text size: a fixed size from the text size control, or (Fit) the size at
  // which the widest line fills the stage.
  function fitFont() {
    const art = $('art');
    const editor = $('artEdit');
    let px = textSize.size();
    if (textSize.isFit()) {
      const text = edit.open ? editor.value : current?.text;
      if (!text) { art.style.fontSize = editor.style.fontSize = ''; return; }
      const cols = Math.max(1, ...text.split('\n').map(s => s.length));
      const probe = document.createElement('canvas').getContext('2d');
      probe.font = `100px ${getComputedStyle(art).fontFamily}`;
      const w = probe.measureText('M').width / 100;
      const avail = $('stage').clientWidth - 24;
      px = Math.max(2, Math.min(18, avail / (cols * w)));
      textSize.showFitSize(px);
    }
    art.style.fontSize = editor.style.fontSize = px + 'px';
  }

  // ---------- hand editing ----------
  // "Edit text" swaps the preview for a textarea. Once the text is changed it replaces the
  // image-generated art: image controls pause, while title, style, Pack and budget still apply.
  const edit = { open: false, active: false, pending: false, text: '', timer: 0 };

  function editorRows(text) { return Math.max(12, text.split('\n').length + 1); }

  function openEditor() {
    const ta = $('artEdit');
    edit.open = true;
    ta.value = edit.active ? edit.text : (current ? current.text : '');
    ta.rows = editorRows(ta.value);
    ta.hidden = false; $('art').hidden = true;
    $('overwriteWrap').hidden = false;
    $('editToggle').textContent = 'Done editing';
    fitFont();
    ta.focus();
  }

  function closeEditor() {
    edit.open = false;
    $('artEdit').hidden = true; $('art').hidden = false;
    $('overwriteWrap').hidden = true;
    $('editToggle').textContent = 'Edit text';
    fitFont();
  }

  async function refreshEdited() {
    const my = ++job;
    const text = edit.text;
    const packIt = $('pack').checked;
    const title = $('title').value.trim();
    const settings = styleSettings();
    const budget = Math.min(MAX_MEMO_BYTES, Math.max(1, +$('budget').value || 0));
    const memo = packIt ? await pack(text) : text;
    if (my !== job) return;
    const lines = text.split('\n');
    edit.pending = false;
    showResult({ text, memo, cols: Math.max(0, ...lines.map(l => l.length)), rows: lines.length }, null, budget, title, settings);
    updateEditNote();
  }

  function updateEditNote() {
    $('editNote').hidden = !edit.active;
    if (!edit.active) return;
    const nonAscii = [...edit.text].filter(ch => ch !== '\n' && (ch < ' ' || ch > '~')).length;
    $('editNoteText').textContent = 'Edited by hand: image settings are paused (title, style, Pack and budget still apply).'
      + (nonAscii ? ` ${nonAscii} non-ASCII character${nonAscii > 1 ? 's use' : ' uses'} extra bytes and may not line up in every font.` : '');
  }

  function discardEdits(rerender = true) {
    saveDraftSoon();
    edit.active = edit.pending = false;
    edit.text = '';
    clearTimeout(edit.timer);
    if (edit.open) closeEditor();
    updateEditNote();
    if (rerender) {
      if (img) schedule();
      else { current = null; $('art').textContent = ''; setMsg('Load an image to begin.'); updateButtons(); }
    }
  }

  $('editToggle').onclick = () => (edit.open ? closeEditor() : openEditor());
  $('editRevert').onclick = () => discardEdits();

  $('artEdit').addEventListener('input', () => {
    const ta = $('artEdit');
    edit.active = true;
    edit.pending = true;
    edit.text = ta.value.replace(/\r\n?/g, '\n').replace(/\t/g, '  ');
    ta.rows = editorRows(edit.text);
    updateButtons();
    clearTimeout(edit.timer);
    edit.timer = setTimeout(refreshEdited, 150);
  });

  // Overwrite typing: a typed character replaces the one under the cursor (like a terminal),
  // so columns stay aligned. At the end of a line it extends the line. Undo still works.
  $('artEdit').addEventListener('beforeinput', e => {
    if (!$('overwrite').checked || e.inputType !== 'insertText' || !e.data || e.data.includes('\n')) return;
    const ta = e.target, start = ta.selectionStart;
    if (start !== ta.selectionEnd) return;
    let lineEnd = ta.value.indexOf('\n', start);
    if (lineEnd < 0) lineEnd = ta.value.length;
    const n = Math.min(e.data.length, lineEnd - start);
    if (n <= 0) return;
    e.preventDefault();
    ta.setSelectionRange(start, start + n);
    if (!document.execCommand('insertText', false, e.data)) {
      ta.setRangeText(e.data, start, start + n, 'end');
      ta.dispatchEvent(new Event('input'));
    }
  });

  // ---------- outputs ----------
  const validAddr = a => /^(t?xch)1[0-9a-z]{20,}$/.test(a);
  function updateButtons() {
    const ok = !!current && !edit.pending;
    $('copy').disabled = $('dlTxt').disabled = $('useFee').disabled = !ok;
    $('dlJson').disabled = !ok || !validAddr($('addr').value.trim());
    $('sageBuild').disabled = !ok || !sage.key || !validAddr($('addr').value.trim()) || sage.busy;
    $('toMyFeed').disabled = !sage.firstAddress;
    const fee = +$('fee').value || 0;
    $('feeXch').textContent = fee ? amounts.format(fee) : '';
    updateFeedNote();
  }
  function memos() { return memoList(current.memo, current.title, current.settings); }
  function download(name, text, type) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  $('copy').onclick = async () => {
    if (await memoArt.copyText(current.memo, 'memo') !== 'copied') return;
    $('copy').textContent = 'Copied'; setTimeout(() => $('copy').textContent = 'Copy memo', 1500);
  };
  $('dlTxt').onclick = () => download('ascii-memory.txt', current.memo, 'text/plain');
  $('useFee').onclick = () => {
    $('fee').value = Math.ceil((BASE_TX_COST + memoBytes(current.memo, current.title, current.settings) * COST_PER_BYTE) * MIN_FPC);
    inputsChanged();
  };
  $('dlJson').onclick = () => {
    const req = {
      wallet_id: +$('walletId').value || 1,
      address: $('addr').value.trim(),
      amount: Math.max(1, +$('amount').value || 1),
      fee: Math.max(0, +$('fee').value || 0),
      memos: memos(),
    };
    download('send_transaction.json', JSON.stringify(req, null, 2), 'application/json');
  };

  // ---------- Sage wallet ----------
  // Two ways to reach Sage:
  //  * 'app'    – running as a Sage App: the bundled sage-runtime-bridge.js exposes window.__SAGE__,
  //               and Sage shows its own approval dialog for every send.
  //  * 'bridge' – running in a normal browser via sage_bridge.py (RPC with Sage's certificate).
  const IN_SAGE = /^sage-app/.test(location.protocol) || /(^|\.)sage-app\.localhost$/.test(location.hostname) || !!window.__TAURI_INTERNALS__;
  const MODE = IN_SAGE ? 'app' : /^https?:$/.test(location.protocol) ? 'bridge' : 'none';
  if (IN_SAGE) document.documentElement.classList.add('in-sage');

  const sage = { key: null, receive: null, network: null, built: null, busy: false };
  const toHex = str => [...enc.encode(str)].map(b => b.toString(16).padStart(2, '0')).join('');
  const short = h => h.length > 24 ? h.slice(0, 14) + '…' + h.slice(-8) : h;
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  async function sageCall(endpoint, body = {}) {
    const r = await fetch('/sage/' + endpoint, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Memo-Art': '1' }, body: JSON.stringify(body),
    });
    const text = await r.text();
    // sage_bridge.py answers errors in text/plain; anything else means the bridge isn't serving this page.
    if (!r.ok && !(r.headers.get('content-type') || '').startsWith('text/plain')) throw Object.assign(new Error('bridge missing'), { bridgeMissing: true });
    if (!r.ok) throw new Error(text || `${r.status} ${r.statusText}`);
    return text ? JSON.parse(text) : {};
  }

  async function sageApp() {
    for (let i = 0; i < 40 && !window.__SAGE__; i++) await new Promise(r => setTimeout(r, 50));
    if (!window.__SAGE__) throw new Error('The Sage app bridge is not available.');
    return window.__SAGE__;
  }

  const fp = key => key.fingerprint == null ? '' : ` (${key.fingerprint})`;
  const NO_BRIDGE_MSG = 'To push with Sage, install the generator as a Sage App, or run <code>python sage_bridge.py</code> and open <a href="http://127.0.0.1:9260/generator.html">http://127.0.0.1:9260/generator.html</a>.';
  function sageMsg(html, cls = '') { $('sageStatus').innerHTML = html; $('sageStatus').className = 'msg ' + cls; }

  async function sageConnect() {
    sage.key = sage.receive = sage.firstAddress = null;
    discardReview();
    if (MODE === 'none') {
      sageMsg(NO_BRIDGE_MSG);
      return updateButtons();
    }
    sageMsg('Connecting to Sage…');
    try {
      let version = '', key, sync;
      if (MODE === 'app') {
        // Apps can't read the active wallet's fingerprint (wallet.getKey requires one), so derive
        // what we need from the sync status: the receive address prefix gives the network.
        const client = await sageApp();
        // My feed watches the first unhardened address (derivation index 0), not the rotating receive address.
        const [status, derivations] = await Promise.all([
          client.wallet.getSyncStatus(),
          client.wallet.getDerivations({ hardened: false, offset: 0, limit: 1 }).catch(() => null),
        ]);
        sync = status;
        sage.firstAddress = derivations?.derivations?.[0]?.address || null;
        const addr = String(sync.receive_address || '');
        key = { key: { name: 'Active Sage wallet', fingerprint: null, has_secrets: true,
          network_id: addr.startsWith('txch1') ? 'testnet11' : 'mainnet' } };
      } else {
        let ver, derivations;
        [ver, key, sync, derivations] = await Promise.all([
          sageCall('get_version'), sageCall('get_key'), sageCall('get_sync_status'),
          sageCall('get_derivations', { hardened: false, offset: 0, limit: 1 }).catch(() => null),
        ]);
        version = ' ' + ver.version;
        sage.firstAddress = derivations?.derivations?.[0]?.address || null;
      }
      if (!key.key) { sageMsg('No wallet is logged in to Sage. Log in, then click Reconnect.', 'bad'); return updateButtons(); }
      if (!key.key.has_secrets) { sageMsg(`Wallet "${esc(key.key.name)}" is watch-only and cannot sign.`, 'bad'); return updateButtons(); }
      sage.key = key.key; sage.network = key.key.network_id; sage.receive = sync.receive_address;
      $('addr').placeholder = (sage.network === 'mainnet' ? 'xch1' : 'txch1') + '…';
      sage.sync = sync; sage.version = version;
      showConnected();
    } catch (e) {
      if (e.bridgeMissing) sageMsg(NO_BRIDGE_MSG);
      else sageMsg((MODE === 'app' ? 'Sage refused: ' : '') + esc(e.message), 'bad');
    }
    updateButtons();
  }

  function showConnected() {
    const { key, sync, network, version } = sage;
    if (!key || !sync) return;
    const syncing = sync.synced_coins < sync.total_coins ? ` · <span style="color:var(--warn)">syncing ${sync.synced_coins}/${sync.total_coins}</span>` : '';
    sageMsg(`Connected to Sage${esc(version || '')} · <b>${esc(key.name)}</b>${fp(key)} · ${esc(network)} · ${amounts.format(sync.selectable_balance)} spendable${syncing}`, 'ok');
  }

  function txParams() {
    return {
      address: $('addr').value.trim(),
      amount: Math.max(1, Math.floor(+$('amount').value || 1)),
      fee: Math.max(0, Math.floor(+$('fee').value || 0)),
      memos: current ? memos().map(toHex) : [],
    };
  }

  function discardReview() {
    sage.built = null;
    $('review').hidden = true;
  }
  function inputsChanged() {
    if (sage.built) { discardReview(); sageMsg('Inputs changed. Build the transaction again before signing.'); }
    updateButtons();
  }

  function checkParams(params) {
    const wantPrefix = sage.network === 'mainnet' ? 'xch1' : 'txch1';
    if (!params.address.startsWith(wantPrefix)) { sageMsg(`The address must start with ${wantPrefix} on ${esc(sage.network)}.`, 'bad'); return null; }
    const bytes = memoBytes(current.memo, current.title, current.settings);
    if (BASE_TX_COST + bytes * COST_PER_BYTE > MAX_TX_COST) { sageMsg('The memo is too large for one transaction.', 'bad'); return null; }
    return bytes;
  }

  // Bridge mode: build unsigned → review → sign.
  async function sageBuild() {
    if (MODE === 'app') return sageSendApp();
    const params = txParams();
    const bytes = checkParams(params);
    if (bytes == null) return;
    sage.busy = true; updateButtons(); $('pushed').hidden = true; discardReview();
    sageMsg('Asking Sage to build the transaction (not signed)…');
    try {
      const res = await sageCall('send_xch', params);
      sage.built = { params: JSON.stringify(params), res, bytes };
      renderReview(sage.built);
      $('review').hidden = false;
      sageMsg('Review the transaction below. Nothing has been signed or sent yet.', 'ok');
    } catch (e) {
      sageMsg('Sage could not build the transaction: ' + esc(e.message), 'bad');
    } finally { sage.busy = false; updateButtons(); }
  }

  // App mode: Sage's own approval dialog is the review step; Sage signs and submits on approval.
  async function sageSendApp() {
    const params = txParams();
    const bytes = checkParams(params);
    if (bytes == null) return;
    sage.busy = true; updateButtons(); $('pushed').hidden = true; discardReview();
    sageMsg('Approve the transaction in Sage’s dialog. The request expires after 30 seconds.');
    try {
      const client = await sageApp();
      const res = await client.wallet.sendXch({
        address: params.address,
        amount: String(params.amount),
        fee: String(params.fee),
        memos: params.memos,
      });
      renderReview({ params: JSON.stringify(params), res, bytes });
      showPushed(res);
    } catch (e) {
      const msg = String(e.message || e);
      if (/timeout|expired/i.test(msg)) sageMsg('No approval within 30 seconds, so nothing was sent. Click Send again when you’re ready.', 'bad');
      else if (/reject|denied|declin|cancel/i.test(msg)) sageMsg('Transaction rejected in Sage. Nothing was sent.', 'bad');
      else sageMsg('Sage could not send the transaction: ' + esc(msg), 'bad');
    } finally { sage.busy = false; updateButtons(); }
  }

  function renderReview({ res, bytes, params }) {
    const p = JSON.parse(params);
    const inputs = res.summary.inputs || [];
    const inTotal = inputs.reduce((t, i) => t + BigInt(i.amount), 0n);
    const outs = inputs.flatMap(i => i.outputs || []);
    const outRows = outs.map(o => `${esc(short(o.address))} · ${amounts.format(o.amount)}${o.receiving ? ' (yours)' : ''}`).join('<br>');
    const fee = Number(res.summary.fee);
    const cost = BASE_TX_COST + bytes * COST_PER_BYTE;
    const feeNote = fee < cost * MIN_FPC ? `<br><span style="color:var(--warn)">Below the suggested ${amounts.format(cost * MIN_FPC)}: fine while the mempool isn't full, otherwise it may not be included.</span>` : '';
    $('reviewTable').innerHTML = `
      <tr><th>Wallet</th><td>${esc(sage.key.name)}${fp(sage.key)} · ${esc(sage.network)}</td></tr>
      <tr><th>Send to</th><td>${esc(p.address)}</td></tr>
      <tr><th>Amount</th><td>${amounts.format(p.amount)}</td></tr>
      <tr><th>Fee</th><td>${amounts.format(fee)}${feeNote}</td></tr>
      <tr><th>Memo</th><td>${bytes.toLocaleString()} bytes in ${p.memos.length} memo${p.memos.length > 1 ? 's' : ''} · est. cost ${(cost / 1e6).toFixed(1)} M</td></tr>
      <tr><th>Inputs</th><td>${inputs.length} coin${inputs.length === 1 ? '' : 's'} · ${amounts.format(inTotal)}</td></tr>
      <tr><th>Outputs</th><td>${outRows || '—'}</td></tr>`;
    $('sageSign').textContent = `Sign & push to ${sage.network}`;
  }

  function showPushed(res) {
    const input = String(res.summary.inputs[0].coin_id).replace(/^0x/, '');
    const net = sage.network === 'mainnet' ? '' : sage.network + ':';
    sageMsg('Transaction pushed. It usually confirms within a minute or two.', 'ok');
    const box = $('pushed');
    box.innerHTML = '';
    const link = `viewer.html#${net}0x${input}`;
    if (MODE === 'app') {
      // Same app, so the View tab can be opened in place (Sage apps can't open new windows).
      box.innerHTML = `<a href="${link}">Open in viewer →</a><br>Coin ID: <code>0x${input}</code> `;
      const btn = document.createElement('button');
      btn.className = 'ghost'; btn.textContent = 'Copy ID';
      btn.onclick = async () => {
        if (await memoArt.copyText('0x' + input, 'coin ID') !== 'copied') return;
        btn.textContent = 'Copied'; setTimeout(() => btn.textContent = 'Copy ID', 1500);
      };
      box.append(btn);
      const table = $('reviewTable').cloneNode(true);
      table.removeAttribute('id');
      box.append(table);
    } else {
      box.innerHTML = `Viewer link: <a href="${link}" target="_blank" rel="noopener">${esc(link)}</a>`;
    }
    box.insertAdjacentHTML('beforeend', '<br>The ID belongs to the coin that was spent, so it keeps working after confirmation. Until then the viewer shows the transaction as pending.');
    box.hidden = false;
  }

  async function sageSign() {
    const built = sage.built;
    if (!built || built.params !== JSON.stringify(txParams())) {
      discardReview(); sageMsg('The inputs changed after the review. Build the transaction again.', 'bad'); return;
    }
    sage.busy = true; $('sageSign').disabled = true; updateButtons();
    sageMsg('Signing in Sage and pushing to the network…');
    try {
      await sageCall('sign_coin_spends', { coin_spends: built.res.coin_spends, auto_submit: true });
      discardReview();
      showPushed(built.res);
    } catch (e) {
      sageMsg('Sage could not sign or submit the transaction: ' + esc(e.message), 'bad');
    } finally { sage.busy = false; $('sageSign').disabled = false; updateButtons(); }
  }

  if (MODE === 'app') {
    $('sageTitle').textContent = 'Send with Sage';
    $('sageBuild').textContent = 'Send with Sage…';
  }
  $('sageConnect').onclick = sageConnect;
  $('sageBuild').onclick = sageBuild;
  $('sageSign').onclick = sageSign;
  $('sageDiscard').onclick = () => { discardReview(); sageMsg('Discarded. Nothing was signed.'); };

  // ---------- THE FEED ----------
  // THE FEED only lists inscriptions that paid the feed address at least FEED_MIN_MOJO (1 XCH).
  const { FEED_ADDRESS, FEED_MIN_MOJO } = window.asciiMemory;

  function updateFeedNote() {
    const amount = Math.floor(+$('amount').value || 0);
    $('amountXch').textContent = amount ? amounts.format(amount) : '';
    const address = $('addr').value.trim();
    const note = $('feedNote');
    note.hidden = false;
    if (address === FEED_ADDRESS) {
      if (amount < FEED_MIN_MOJO) {
        note.className = 'msg bad';
        note.textContent = `Below 1 XCH: THE FEED ignores this transaction. Raise the amount to at least ${amounts.format(FEED_MIN_MOJO)}.`;
      } else {
        note.className = 'msg ok';
        note.textContent = `Sending ${amounts.format(amount)} to THE FEED address: this inscription will appear in THE FEED once confirmed. The XCH goes to the feed owner and cannot be returned.`;
      }
    } else if (sage.firstAddress && address === sage.firstAddress) {
      note.className = 'msg ok';
      note.textContent = 'Your own first address: this inscription will appear in My feed once confirmed, whatever the amount.';
    } else {
      note.hidden = true;
    }
  }

  function fillAddress(address, minAmount) {
    $('addr').value = address;
    if ((+$('amount').value || 0) < minAmount) $('amount').value = minAmount;
    inputsChanged();
    saveDraftSoon();
    $('addr').scrollIntoView({ block: 'center', behavior: 'smooth' });
  }

  $('toFeed').onclick = () => fillAddress(FEED_ADDRESS, FEED_MIN_MOJO);
  // My feed watches the wallet's first unhardened address; 1 mojo is enough there.
  $('toMyFeed').onclick = () => { if (sage.firstAddress) fillAddress(sage.firstAddress, 1); };
  ['addr', 'amount', 'fee', 'title'].forEach(id => $(id).addEventListener('input', inputsChanged));
  $('theme').addEventListener('change', inputsChanged);
  amounts.onChange(() => {
    updateButtons();                       // fee/amount labels and the feed note
    showConnected();                       // wallet balance
    if (current) {                         // suggested-fee stat (a full re-render would drop a pending review)
      const bytes = memoBytes(current.memo, current.title, current.settings);
      $('sFee').textContent = amounts.format((BASE_TX_COST + bytes * COST_PER_BYTE) * MIN_FPC);
    }
    if (sage.built) renderReview(sage.built);
  });

  sageConnect();

  // ---------- session draft ----------
  // The Generate and View tabs are separate pages, so switching tabs reloads this page.
  // Keep the work for the session: form fields, hand edits and a downscaled copy of the image.
  const DRAFT_KEY = 'memoart.generatorDraft';
  // Order matters: the style sets Invert, the character preset sets the ramp, the width mode sets cols.
  const DRAFT_FIELDS = ['budget', 'widthMode', 'cols', 'pack', 'title', 'theme', 'rampPreset', 'ramp',
    'brightness', 'contrast', 'gamma', 'sharpen', 'aspect', 'dither', 'invert', 'trim',
    'addr', 'amount', 'fee', 'walletId', 'overwrite'];
  let draftTimer = 0, restoring = false, imageData = null;

  function imageDataUrl(im) {
    const max = 1600, k = Math.min(1, max / Math.max(im.naturalWidth, im.naturalHeight));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(im.naturalWidth * k));
    c.height = Math.max(1, Math.round(im.naturalHeight * k));
    c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
    const webp = c.toDataURL('image/webp', 0.92);   // keeps transparency, much smaller than PNG
    return webp.startsWith('data:image/webp') ? webp : c.toDataURL('image/png');
  }

  function saveDraftSoon(opts = {}) {
    if (restoring) return;
    if (opts.image) imageData = null;                 // new image: re-encode it on save
    clearTimeout(draftTimer);
    draftTimer = setTimeout(saveDraft, 400);
  }

  function saveDraft() {
    const fields = {};
    for (const id of DRAFT_FIELDS) {
      const el = $(id);
      if (el) fields[id] = el.type === 'checkbox' ? el.checked : el.value;
    }
    if (img && !imageData) {
      try { imageData = { url: imageDataUrl(img), name: imageName }; } catch { imageData = null; }
    }
    const draft = { v: 1, fields, image: imageData, edit: edit.active ? { text: edit.text } : null };
    try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify(draft)); }
    catch {
      // Over quota (very large image): keep everything except the image.
      try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ ...draft, image: null })); } catch { /* storage unavailable */ }
    }
  }

  function restoreDraft() {
    let draft = null;
    try { draft = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null'); } catch { draft = null; }
    if (!draft || draft.v !== 1) return;
    restoring = true;
    try {
      for (const id of DRAFT_FIELDS) {
        const el = $(id), v = draft.fields?.[id];
        if (!el || v === undefined) continue;
        if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
        // Let each control's own handler update its labels and dependent UI.
        el.dispatchEvent(new Event(el.tagName === 'SELECT' || el.type === 'checkbox' ? 'change' : 'input'));
      }
      if (draft.edit) { edit.active = true; edit.text = draft.edit.text; updateEditNote(); }
      imageData = draft.image || null;
    } finally {
      restoring = false;
    }
    if (draft.image) showImage(draft.image.url, draft.image.name, true);
    else if (edit.active) refreshEdited();
  }

  // Capture phase: also sees events that don't bubble (e.g. dispatched by other scripts).
  document.addEventListener('input', () => saveDraftSoon(), true);
  document.addEventListener('change', () => saveDraftSoon(), true);
  restoreDraft();
})();
