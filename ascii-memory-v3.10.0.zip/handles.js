// Chia name services, shared by the Generate and View tabs: "@name" → the xch1 address it points at.
//
// Two independent services are asked at once, because the same name can be registered in both and
// point at different addresses:
//   XCHandles (api.xchandles.com) → the handle's slot and its resolved NFT singleton; the address is
//                                   that NFT's p2 puzzle hash, encoded as bech32m.
//   Namesdao  (api.namesdao.org)  → /v1/resolve returns the address directly.
// Callers must handle the conflict case: when the two answers differ, nothing is chosen for you.
// Both services are mainnet only.
(() => {
  const XCHANDLES_API = 'https://api.xchandles.com';
  const NAMESDAO_API = 'https://api.namesdao.org';
  // Namesdao names may contain - and _ and are written "name.xch"; XCHandles allows only a-z0-9.
  const RE = /^@([a-z0-9][a-z0-9_-]{1,62})(\.xch)?$/;
  const XCHANDLES_RE = /^[a-z0-9]{3,63}$/;

  // "@Name.xch" → "name" when it is a well-formed name, otherwise null.
  const parse = raw => {
    const m = String(raw || '').trim().toLowerCase().match(RE);
    return m ? m[1] : null;
  };

  // puzzle hash (hex) → bech32m address
  function encodeAddress(hrp, hex) {
    const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
    const data = [];
    let acc = 0, bits = 0;
    for (let i = 0; i < hex.length; i += 2) {
      acc = (acc << 8) | parseInt(hex.substr(i, 2), 16); bits += 8;
      while (bits >= 5) { bits -= 5; data.push((acc >> bits) & 31); }
    }
    if (bits) data.push((acc << (5 - bits)) & 31);
    const GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
    const polymod = values => {
      let chk = 1;
      for (const v of values) {
        const top = chk >>> 25;
        chk = ((chk & 0x1ffffff) << 5) ^ v;
        for (let i = 0; i < 5; i++) if ((top >>> i) & 1) chk ^= GEN[i];
      }
      return chk;
    };
    const expanded = [...[...hrp].map(c => c.charCodeAt(0) >> 5), 0, ...[...hrp].map(c => c.charCodeAt(0) & 31)];
    const mod = polymod([...expanded, ...data, 0, 0, 0, 0, 0, 0]) ^ 0x2bc830a3;
    const checksum = [0, 1, 2, 3, 4, 5].map(i => (mod >>> (5 * (5 - i))) & 31);
    return hrp + '1' + [...data, ...checksum].map(v => CHARSET[v]).join('');
  }

  const isAddress = a => /^xch1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{20,}$/.test(a || '');

  async function resolveXchandles(name) {
    if (!XCHANDLES_RE.test(name)) throw new Error(`@${name} cannot be an XCHandle (they allow only 3 to 63 letters and digits).`);
    const get = async path => {
      const res = await fetch(XCHANDLES_API + path);
      if (res.status === 404) throw new Error(`@${name} is not registered.`);
      if (res.status === 410) throw new Error(`@${name} has expired.`);
      if (!res.ok) throw new Error(`XCHandles answered HTTP ${res.status}.`);
      return res.json();
    };
    const d = await get(`/handle/${name}`);
    if (d.slot?.expiration && d.slot.expiration * 1000 < Date.now()) throw new Error(`@${name} has expired.`);
    let single = d.resolved_singleton;
    if (!single?.nft && d.slot?.resolved_launcher_id) single = await get(`/singletons/${d.slot.resolved_launcher_id}`);
    if (single?.melted) throw new Error(`@${name} points at an NFT that no longer exists.`);
    const ph = String(single?.nft?.p2_puzzle_hash || '').toLowerCase().replace(/^0x/, '');
    if (!/^[0-9a-f]{64}$/.test(ph)) throw new Error(`@${name} does not point at an address.`);
    return encodeAddress('xch', ph);
  }

  async function resolveNamesdao(name) {
    const res = await fetch(`${NAMESDAO_API}/v1/resolve?name=${encodeURIComponent(name)}.xch`);
    if (res.status === 404) throw new Error(`${name}.xch is not registered.`);
    if (!res.ok) throw new Error(`Namesdao answered HTTP ${res.status}.`);
    const d = await res.json();
    const address = String(d.address || '').toLowerCase();
    if (!isAddress(address)) throw new Error(`${name}.xch does not point at an XCH address.`);
    return address;
  }

  const SERVICES = [
    { id: 'xchandles', name: 'XCHandles', shown: n => `@${n}`, resolve: resolveXchandles },
    { id: 'namesdao', name: 'Namesdao', shown: n => `${n}.xch`, resolve: resolveNamesdao },
  ];

  // Asks both services and reports what each said:
  //   { name, results: [{ id, service, address, error }], found: [...], addresses: [...],
  //     address: the address when both agree or only one service knows the name,
  //     conflict: true when the two services disagree (address is then null),
  //     agree:    true when both returned the same address,
  //     summary:  one line for the UI }
  async function resolveAll(name) {
    const results = await Promise.all(SERVICES.map(async s => {
      try { return { id: s.id, service: s.name, shown: s.shown(name), address: await s.resolve(name), error: null }; }
      catch (e) { return { id: s.id, service: s.name, shown: s.shown(name), address: null, error: e.message || String(e) }; }
    }));
    const found = results.filter(r => r.address);
    const addresses = [...new Set(found.map(r => r.address))];
    const conflict = addresses.length > 1;
    const agree = found.length === SERVICES.length && addresses.length === 1;
    const address = conflict ? null : addresses[0] || null;
    let summary;
    if (conflict) summary = `@${name} points at different addresses in XCHandles and Namesdao. Pick the one you mean.`;
    else if (agree) summary = `@${name} → ${address} (XCHandles and Namesdao agree)`;
    else if (address) summary = `@${name} → ${address} (${found[0].service} only; ${results.find(r => !r.address).service}: ${results.find(r => !r.address).error})`;
    else summary = `@${name} was not found. ${results.map(r => `${r.service}: ${r.error}`).join(' ')}`;
    return { name, results, found, addresses, address, conflict, agree, summary };
  }

  window.asciiHandles = {
    parse, resolveAll, resolveXchandles, resolveNamesdao, encodeAddress, SERVICES,
    FORMAT_HINT: 'A name is @ followed by 3 to 63 letters, digits, - or _, e.g. @cassfairiesclub (Namesdao names may be written @name.xch).',
  };
})();
