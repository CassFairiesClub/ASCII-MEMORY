// Text size control shared by generator.html and viewer.html:
//   [x] Fit   A−  [slider]  A+  12 px
// "Fit" sizes the art to the width of its box (the page computes that size and reports it back
// with showFitSize, so the slider follows). Moving the slider or pressing A−/A+ switches to that
// fixed size; ticking Fit again returns to automatic sizing. The choice is remembered per page.
// Pages start at a fixed DEFAULT size, with Fit off.
(() => {
  const MIN = 2, MAX = 40, DEFAULT = 4;

  function create({ root, storageKey, onChange }) {
    const q = sel => root.querySelector(sel);
    const fit = q('[data-ts="fit"]'), slider = q('[data-ts="slider"]');
    const minus = q('[data-ts="minus"]'), plus = q('[data-ts="plus"]'), label = q('[data-ts="label"]');
    slider.min = MIN; slider.max = MAX; slider.step = 1;

    const clamp = v => Math.min(MAX, Math.max(MIN, Math.round(v)));
    const show = px => { slider.value = clamp(px); label.textContent = `${Math.round(px * 10) / 10} px`; };

    // Saved choices are versioned: raising the version makes every page start again from DEFAULT.
    storageKey += '.v2';
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(storageKey) || 'null'); } catch { saved = null; }
    fit.checked = saved ? !!saved.fit : false;
    show(saved && Number.isFinite(saved.size) ? saved.size : DEFAULT);

    const persist = () => {
      try { localStorage.setItem(storageKey, JSON.stringify({ fit: fit.checked, size: +slider.value })); } catch { /* storage unavailable */ }
    };
    const setFixed = px => { fit.checked = false; show(clamp(px)); persist(); onChange(); };

    fit.addEventListener('change', () => { persist(); onChange(); });
    slider.addEventListener('input', () => setFixed(+slider.value));
    minus.addEventListener('click', () => setFixed(+slider.value - (+slider.value > 12 ? 2 : 1)));
    plus.addEventListener('click', () => setFixed(+slider.value + (+slider.value >= 12 ? 2 : 1)));

    return {
      isFit: () => fit.checked,
      size: () => +slider.value,
      showFitSize: px => { if (fit.checked) show(px); },
    };
  }

  window.memoArtTextSize = { create, MIN, MAX, DEFAULT };
})();
