// Home page: fills in the preset amounts and the wall address.
(() => {
  const { FEED_ADDRESS, FEED_MIN_MOJO } = window.asciiMemory;
  const amounts = window.asciiAmounts;
  if (window.memoArt?.IN_SAGE) document.documentElement.classList.add('in-sage');

  function showAmounts() {
    for (const el of document.querySelectorAll('[data-mojo]')) {
      el.textContent = amounts.format(el.dataset.mojo === 'feed' ? FEED_MIN_MOJO : el.dataset.mojo);
    }
  }

  document.getElementById('feedAddress').textContent = FEED_ADDRESS;
  const copy = document.getElementById('copyFeed');
  copy.addEventListener('click', async () => {
    if (await memoArt.copyText(FEED_ADDRESS, 'wall address') !== 'copied') return;
    copy.textContent = 'Copied';
    setTimeout(() => { copy.textContent = 'Copy address'; }, 1500);
  });

  showAmounts();
})();
