// One place to format Chia amounts, shared by every page.
//
// Amounts are always given in mojo (Number, BigInt or numeric string) and shown with the
// locale's thousands and decimal separators, always in both units: "1.5 XCH (1,500,000,000,000 mojo)".
// Conversion uses BigInt, so amounts beyond 2^53 mojo stay exact.
(() => {
  const MOJO_PER_XCH = 1_000_000_000_000n;

  const groups = new Intl.NumberFormat(undefined, { useGrouping: true });
  const DECIMAL = new Intl.NumberFormat(undefined).formatToParts(1.1).find(p => p.type === 'decimal')?.value || '.';

  const toBigInt = value => {
    if (typeof value === 'bigint') return value;
    if (typeof value === 'number') return BigInt(Math.round(value));
    return BigInt(String(value ?? '0').trim() || '0');
  };

  function xchText(mojo) {
    const negative = mojo < 0n;
    const abs = negative ? -mojo : mojo;
    const whole = abs / MOJO_PER_XCH;
    const fraction = (abs % MOJO_PER_XCH).toString().padStart(12, '0').replace(/0+$/, '');
    return (negative ? '-' : '') + groups.format(whole) + (fraction ? DECIMAL + fraction : '');
  }

  const mojoText = mojo => groups.format(mojo);

  // format(1500000000000) → "1.5 XCH (1,500,000,000,000 mojo)"
  const format = value => {
    const mojo = toBigInt(value);
    return `${xchText(mojo)} XCH (${mojoText(mojo)} mojo)`;
  };

  window.asciiAmounts = { format, xch: v => `${xchText(toBigInt(v))} XCH`, mojo: v => `${mojoText(toBigInt(v))} mojo` };
})();
