// Terminal display styles shared by generator.html and viewer.html.
//
// The generator stores the chosen style in its own small memo next to the art:
//   memoart:v1;theme=green-crt
// and the viewer reads it back so the art is shown the way it was made.
// Only the style id is stored; the colours below are the single source of truth.
(() => {
  const MONO = 'ui-monospace, "Cascadia Mono", Consolas, "DejaVu Sans Mono", monospace';

  const THEMES = [
    { id: 'paper', name: 'Paper · dark ink on light', bg: '#fffdf8', fg: '#111111', dark: false, font: MONO },
    { id: 'classic', name: 'Classic terminal · white on black', bg: '#000000', fg: '#e8e8e8', dark: true,
      font: '"Lucida Console", "Courier New", ' + MONO },
    { id: 'green-crt', name: 'Green phosphor CRT', bg: '#031a07', fg: '#39ff6a', dark: true, font: MONO,
      glow: 'rgba(57, 255, 106, 0.55)', scanlines: true },
    { id: 'amber-crt', name: 'Amber CRT', bg: '#150d00', fg: '#ffb31a', dark: true, font: MONO,
      glow: 'rgba(255, 179, 26, 0.5)', scanlines: true },
    { id: 'ubuntu', name: 'Ubuntu terminal', bg: '#300a24', fg: '#eeeeec', dark: true,
      font: '"Ubuntu Mono", "DejaVu Sans Mono", ' + MONO },
    { id: 'powershell', name: 'Windows PowerShell', bg: '#012456', fg: '#eeedf0', dark: true,
      font: 'Consolas, "Cascadia Mono", ' + MONO },
    { id: 'c64', name: 'Commodore 64', bg: '#40318d', fg: '#a79dff', dark: true, font: MONO },
    { id: 'solarized-dark', name: 'Solarized Dark', bg: '#002b36', fg: '#93a1a1', dark: true, font: MONO },
  ];
  const DEFAULT = 'paper';
  const byId = id => THEMES.find(t => t.id === id) || THEMES.find(t => t.id === DEFAULT);

  const PREFIX = 'memoart:v1;';

  function encodeSettings(settings) {
    return PREFIX + Object.entries(settings)
      .filter(([, v]) => v != null && v !== '')
      .map(([k, v]) => `${k}=${String(v).replace(/[;=\s]/g, '')}`)
      .join(';');
  }

  // Returns the settings object, or null when the memo isn't a settings memo.
  function parseSettings(text) {
    if (typeof text !== 'string' || !text.startsWith(PREFIX) || text.length > 512) return null;
    const settings = {};
    for (const pair of text.slice(PREFIX.length).split(';')) {
      const i = pair.indexOf('=');
      if (i > 0) settings[pair.slice(0, i)] = pair.slice(i + 1);
    }
    return settings;
  }

  // Styles a container (background, scanlines) and the <pre> inside it (colour, font, glow).
  function apply(stage, pre, theme) {
    stage.style.backgroundColor = theme.bg;
    stage.style.backgroundImage = theme.scanlines
      ? 'repeating-linear-gradient(to bottom, rgba(0,0,0,0.28) 0, rgba(0,0,0,0.28) 1px, transparent 1px, transparent 3px)'
      : '';
    stage.style.color = theme.fg;
    pre.style.color = theme.fg;
    pre.style.fontFamily = theme.font;
    pre.style.textShadow = theme.glow ? `0 0 3px ${theme.glow}, 0 0 8px ${theme.glow}` : '';
  }

  function fillSelect(select, { auto } = {}) {
    select.textContent = '';
    if (auto) select.append(new Option(auto, 'auto'));
    for (const t of THEMES) select.append(new Option(t.name, t.id));
  }

  window.memoArtThemes = { THEMES, DEFAULT, byId, encodeSettings, parseSettings, apply, fillSelect };
})();
