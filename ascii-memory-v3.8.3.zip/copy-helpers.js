// Copy / export helpers shared by generator.html and viewer.html.
//
// Inside a Sage App webview the async Clipboard API is refused and file downloads do nothing,
// and Sage offers apps no clipboard or file method. What still works there is the webview's
// own selection copy (execCommand) and its native right-click menu on images, so:
//   copyText()  → selection copy, then Clipboard API, then a pre-selected text box (Ctrl+C)
//   showImage() → a popup with the image, to right-click → Copy image / Save image as
(() => {
  const IN_SAGE = /^sage-app/.test(location.protocol) || /(^|\.)sage-app\.localhost$/.test(location.hostname)
    || !!window.__TAURI__ || !!window.__TAURI_INTERNALS__;

  function selectionCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;';
    document.body.append(ta);
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, text.length);
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { ok = false; }
    ta.remove();
    return ok;
  }

  // Must be called from a click handler (user activation). Resolves to 'copied' or 'manual'.
  async function copyText(text, label = 'text') {
    // In Sage try the synchronous path first, while the click's user activation is fresh.
    if (IN_SAGE && selectionCopy(text)) return 'copied';
    try {
      await navigator.clipboard.writeText(text);
      return 'copied';
    } catch { /* fall through */ }
    if (!IN_SAGE && selectionCopy(text)) return 'copied';
    showText(text, label);
    return 'manual';
  }

  function modal(titleText) {
    const back = document.createElement('div');
    back.className = 'ma-modal';
    back.setAttribute('role', 'dialog');
    back.setAttribute('aria-modal', 'true');
    const box = document.createElement('div');
    box.className = 'ma-modal-box';
    const head = document.createElement('div');
    head.className = 'ma-modal-head';
    const h = document.createElement('strong');
    h.textContent = titleText;
    const close = document.createElement('button');
    close.type = 'button'; close.className = 'ghost'; close.textContent = 'Close';
    head.append(h, close);
    box.append(head);
    back.append(box);
    const done = () => { back.remove(); document.removeEventListener('keydown', onKey); };
    const onKey = e => { if (e.key === 'Escape') done(); };
    close.onclick = done;
    back.addEventListener('click', e => { if (e.target === back) done(); });
    document.addEventListener('keydown', onKey);
    document.body.append(back);
    return { box, done };
  }

  function note(text) {
    const p = document.createElement('p');
    p.className = 'ma-modal-note';
    p.textContent = text;
    return p;
  }

  function showText(text, label) {
    const { box } = modal(`Copy ${label}`);
    const ta = document.createElement('textarea');
    ta.className = 'ma-modal-text';
    ta.value = text;
    ta.readOnly = true;
    ta.rows = Math.min(16, Math.max(2, text.split('\n').length));
    box.append(note('Copying to the clipboard is blocked here. The text is selected: press Ctrl+C (⌘C on Mac).'), ta);
    ta.focus();
    ta.select();
  }

  // Shows a PNG blob so it can be copied or saved with the webview's right-click menu.
  function showImage(blob, filename) {
    const url = URL.createObjectURL(blob);
    const { box } = modal(filename);
    const img = document.createElement('img');
    img.className = 'ma-modal-img';
    img.alt = filename;
    img.src = url;
    box.append(note('Right-click the image and choose “Copy image” or “Save image as…”.'), img);
    const observer = new MutationObserver(() => {
      if (!box.isConnected) { URL.revokeObjectURL(url); observer.disconnect(); }
    });
    observer.observe(document.body, { childList: true });
  }

  window.memoArt = { IN_SAGE, copyText, showText, showImage };
})();
