// Chia name services, shared by the Generate and View tabs: a name → the xch1 address it points at.
//
// The two services are separate namespaces, and the way the name is written picks one:
//   "@name"     → XCHandles (api.xchandles.com): the handle's resolved NFT singleton, whose p2
//                 puzzle hash is encoded as a bech32m address.
//   "name.xch"  → Namesdao (api.namesdao.org): /v1/resolve returns the address directly.
// The other namespace is looked up as well, only to warn when it holds the same name at a different
// address, in case the writer meant the other one. It is never used without the user asking.
// Both services are mainnet only.
(() => {
  const XCHANDLES_API = 'https://api.xchandles.com';
  const NAMESDAO_API = 'https://api.namesdao.org';
  // Namesdao names may contain - and _; XCHandles allows only a-z0-9.
  const NAME_RE = /^[a-z0-9][a-z0-9_-]{1,62}$/;
  const XCHANDLES_RE = /^[a-z0-9]{3,63}$/;

  // What the user typed → { name, service } picked by the namespace they wrote, or null.
  //   "@name" → XCHandles      "name.xch" / "@name.xch" → Namesdao
  const parse = raw => {
    let text = String(raw || '').trim().toLowerCase();
    let service = null;
    if (text.endsWith('.xch')) { service = 'namesdao'; text = text.slice(0, -4); }
    if (text.startsWith('@')) { service = service || 'xchandles'; text = text.slice(1); }
    if (!service || !NAME_RE.test(text)) return null;
    return { name: text, service };
  };

  const written = (name, service) => (service === 'namesdao' ? `${name}.xch` : `@${name}`);

  // puzzle hash (hex) → bech32m address
  function encodeAddress(hrp, hex) {
    const CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
    const data = [];
    let acc = 0, bits = 0;
    for (let i = 0; i < hex.length; i += 2) {
      acc = (acc << 8) | parseInt(hex.substr(i, 2), 16); bits += 8;
      while (bits >= 5) { bits -= 5; data.push((acc >> bits) & 31); }
    }
    if (bits) data.push((acc << (5 - bits)) & 31);
    const GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
    const polymod = values => {
      let chk = 1;
      for (const v of values) {
        const top = chk >>> 25;
        chk = ((chk & 0x1ffffff) << 5) ^ v;
        for (let i = 0; i < 5; i++) if ((top >>> i) & 1) chk ^= GEN[i];
      }
      return chk;
    };
    const expanded = [...[...hrp].map(c => c.charCodeAt(0) >> 5), 0, ...[...hrp].map(c => c.charCodeAt(0) & 31)];
    const mod = polymod([...expanded, ...data, 0, 0, 0, 0, 0, 0]) ^ 0x2bc830a3;
    const checksum = [0, 1, 2, 3, 4, 5].map(i => (mod >>> (5 * (5 - i))) & 31);
    return hrp + '1' + [...data, ...checksum].map(v => CHARSET[v]).join('');
  }

  const isAddress = a => /^xch1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{20,}$/.test(a || '');

  async function resolveXchandles(name) {
    if (!XCHANDLES_RE.test(name)) throw new Error(`@${name} cannot be an XCHandle (they allow only 3 to 63 letters and digits).`);
    const get = async path => {
      const res = await fetch(XCHANDLES_API + path);
      if (res.status === 404) throw new Error(`@${name} is not registered.`);
      if (res.status === 410) throw new Error(`@${name} has expired.`);
      if (!res.ok) throw new Error(`XCHandles answered HTTP ${res.status}.`);
      return res.json();
    };
    const d = await get(`/handle/${name}`);
    if (d.slot?.expiration && d.slot.expiration * 1000 < Date.now()) throw new Error(`@${name} has expired.`);
    let single = d.resolved_singleton;
    if (!single?.nft && d.slot?.resolved_launcher_id) single = await get(`/singletons/${d.slot.resolved_launcher_id}`);
    if (single?.melted) throw new Error(`@${name} points at an NFT that no longer exists.`);
    const ph = String(single?.nft?.p2_puzzle_hash || '').toLowerCase().replace(/^0x/, '');
    if (!/^[0-9a-f]{64}$/.test(ph)) throw new Error(`@${name} does not point at an address.`);
    return encodeAddress('xch', ph);
  }

  async function resolveNamesdao(name) {
    const res = await fetch(`${NAMESDAO_API}/v1/resolve?name=${encodeURIComponent(name)}.xch`);
    if (res.status === 404) throw new Error(`${name}.xch is not registered.`);
    if (!res.ok) throw new Error(`Namesdao answered HTTP ${res.status}.`);
    const d = await res.json();
    const address = String(d.address || '').toLowerCase();
    if (!isAddress(address)) throw new Error(`${name}.xch does not point at an XCH address.`);
    return address;
  }

  const SERVICES = [
    { id: 'xchandles', name: 'XCHandles', shown: n => `@${n}`, resolve: resolveXchandles },
    { id: 'namesdao', name: 'Namesdao', shown: n => `${n}.xch`, resolve: resolveNamesdao },
  ];

  // Resolves the namespace the user wrote, and checks the other one only to warn about a clash:
  //   { name, service, shown, address, error,        ← the namespace that was written
  //     other: { service, shown, address, error },   ← the other namespace, for the warning
  //     conflict: true when the other namespace holds the same name at a different address,
  //     summary: one line for the UI }
  async function resolveAll(input) {
    const picked = typeof input === 'string' ? { name: input, service: 'xchandles' } : input;
    const { name, service } = picked;
    const lookup = async id => {
      const s = SERVICES.find(x => x.id === id);
      try { return { id, service: s.name, shown: written(name, id), address: await s.resolve(name), error: null }; }
      catch (e) { return { id, service: s.name, shown: written(name, id), address: null, error: e.message || String(e) }; }
    };
    const otherId = service === 'namesdao' ? 'xchandles' : 'namesdao';
    const [mine, other] = await Promise.all([lookup(service), lookup(otherId)]);
    const conflict = !!(mine.address && other.address && mine.address !== other.address);
    let summary;
    if (mine.address && conflict) summary = `${mine.shown} → ${mine.address} (${mine.service})`;
    else if (mine.address && other.address) summary = `${mine.shown} → ${mine.address} (${mine.service}; ${other.shown} points at the same address)`;
    else if (mine.address) summary = `${mine.shown} → ${mine.address} (${mine.service})`;
    else summary = `${mine.shown}: ${mine.error}`;
    return { ...mine, name, other, conflict, summary };
  }

  window.asciiHandles = {
    parse, resolveAll, resolveXchandles, resolveNamesdao, encodeAddress, written, SERVICES,
    FORMAT_HINT: 'Write an XCHandle as @name (3 to 63 letters and digits) or a Namesdao name as name.xch.',
  };
})();
