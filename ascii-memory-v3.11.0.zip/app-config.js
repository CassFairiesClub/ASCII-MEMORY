// App-wide settings shared by every page.
window.asciiMemory = Object.freeze({
  NAME: 'ASCII-MEMORY',
  // Kept in step with sage-manifest.json by build_sage_app.py.
  VERSION: '3.11.0',
  CREDIT: 'ASCII-MEMORY by Cass - 2026',
  // The Wall watches this address and only shows inscriptions that sent it at least FEED_MIN_MOJO.
  FEED_ADDRESS: 'xch1khfj4wj6wt783wxzysgt5etws3hy2s03025k0m3dy707ul8x9hnq2w0cym',
  FEED_MIN_MOJO: 1_000_000_000_000, // 1 XCH
});

// Every page's nav bar ends with <span class="app-version">; show which version is running.
document.addEventListener('DOMContentLoaded', () => {
  for (const el of document.querySelectorAll('.app-version')) el.textContent = 'v' + window.asciiMemory.VERSION;
});
